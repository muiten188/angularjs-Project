# Tutorial

* http://blog.teamtreehouse.com/26017-2
* http://angular-tips.com/blog/2015/06/using-angular-1-dot-x-with-es6-and-webpack/
* http://shmck.herokuapp.com/webpack-angular-part-1/
* http://www.shmck.com/webpack-angular-part-2/
* http://www.shmck.com/webpack-angular-part-3/

#Libary
* https://wix.github.io/angular-tree-control/#multi-selection
* http://angularscript.com/simple-angular-directive-for-folder-tree-structure/
* http://hxlniada.github.io/angular-tree-view/
* http://jsfiddle.net/eu81273/8LWUc/18/
* http://htmlpreview.github.io/?https://github.com/kjvelarde/angular-multiselectsearchtree/blob/master/demo/index.html
* http://plnkr.co/edit/NjxjTp?p=preview
* http://thienhung1989.github.io/angular-tree-dnd/demo/#/custom-options
* http://alexsuleap.github.io/
* https://bootsnipp.com/snippets/featured/bootstrap-30-treeview

#Note

When app import, must be have  propertype `name`;
When u work with selection, u set default value for option, u must convert it to string.

#Install
1. Download package : npm install`
1. Run package : npm run dev`