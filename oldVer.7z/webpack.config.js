'use strict';

// Modules
var conf = require('./env.js');
var webpack = require('webpack');
var path = require("path");
var autoprefixer = require('autoprefixer');
var HtmlWebpackPlugin = require('html-webpack-plugin');
var ExtractTextPlugin = require('extract-text-webpack-plugin');
var WebpackAutoInject = require('webpack-auto-inject-version');
var CopyWebpackPlugin = require('copy-webpack-plugin');
var MergeJsonWebpackPlugin = require("merge-jsons-webpack-plugin");

const lib_dir = __dirname + '/public/libraries',
    node_dir = __dirname + '/node_modules',
    bower_dir = __dirname + '/bower_components',
    plugins_dir = __dirname + '/public/plugins';

module.exports = {
    context: __dirname + '/app',
    clientLogLevel: "error",
    entry: {
        app: [__dirname + '/app/app.js'],
        vendor: [
            'babel-polyfill',
            'admin-lte',
            'bootstrap',
            'underscore',
            'angular',
            'ng-storage',
            'angular-animate',
            'angular-motion',
            'angular-filter',
            'angular-sanitize',
            'angular-translate',
            'angular-ui-tree',
            'angular-translate-loader-static-files',
            'angular-ui-notification',
            'angular-ui-notification/build/angular-ui-notification.templates',
            'angular-strap',
            'angular-strap/dist/angular-strap.tpl.min',
            "angular-ui-tinymce",
            "angular-ui-switch",
            "ng-file-upload"
        ]
    },

    resolve: {
        root: path.resolve(__dirname),
        modulesDirectories: ['node_modules', 'bower_components'],
        extensions: ['', '.js', '.json', '.scss', '.html', '.css'],
        alias: {
            angular: node_dir + '/angular',
        }
    },

    output: {
        path: path.join(__dirname, conf.OUTPUT_PATH),
        filename: '[name].js',
        publicPath: conf.PUCLIC_PATH, // want to add to folder (add folder in here)
        sourceMapFileName: '[file].map'
    },
    devServer: {
        inline: true,
        host: process.env.IP || conf.IP,
        port: process.env.PORT || conf.PORT,
        historyApiFallback: true, // remove #
        contentBase: conf.OUTPUT_PATH,
        outputPath: path.join(__dirname, conf.OUTPUT_PATH)
    },
    module: {
        loaders: [
            {
                test: /\.css$/,
                loader: "style-loader!css"
            },
            {
                test: /\.js$/,
                loader: 'babel?presets[]=es2015',
                exclude: /node_modules|bower_components/
            },
            {
                test: /\.(woff|woff2|ttf|eot|svg)(\?]?.*)?$/,
                loader: 'url-loader?name=static/font/[name].[ext]?[hash]&limit=10000'
            },
            {
                test: /\.html$/,
                loader: 'html-loader'
            },
            {
                test: /\.(jpg|png|gif|jpeg)(\?]?.*)?$/,
                loader: `file-loader?name=static/image/[name].[ext]?[hash]`
            },
            {
                // Load i18n files
                test: /\.json$/,
                loader: 'json-loader',
                include: path.resolve('./app/static/i18n')
            }
        ]
    },
    plugins: [
        // new webpack.optimize.CommonsChunkPlugin('app', `static/ib/app.js`, Infinity),
        // new webpack.optimize.CommonsChunkPlugin('vendors', `static/ib/vendors.js`, Infinity),
        new webpack.optimize.OccurenceOrderPlugin(),
        new webpack.optimize.DedupePlugin(), // Remove Deduplicate
        new CopyWebpackPlugin([
            { from: '.htaccess', to: '.htaccess', toType: 'file' },
            { from: 'static/css', to: 'static/css' },
            { from: 'static/fonts', to: 'static/fonts' },
            { from: 'static/image', to: 'static/image' },
            { from: 'static/lib', to: 'static/lib' },
            { from: 'static/menu', to: 'static/menu' },
            { from: 'components/**/include/*.html', to: '[name].[ext]' },
            { from: 'data', to: 'data' },
            // { from: 'static/image', to: 'dist/img' },
            // { from: __dirname + '/node_modules/admin-lte/dist/img', to: 'static/image' }
        ]),
        new webpack.ProvidePlugin({
            '$': "jquery",
            'window.jQuery': "jquery",
            'jQuery': 'jquery',
            'window.$': 'jquery',
            '_': 'underscore'
        }),
        new HtmlWebpackPlugin({
            hash: true,
            inject: "head",
            baseHref: conf.PUCLIC_PATH,
            filename: 'index.html',
            template: __dirname + '/app/index.ejs',
            links: [
                `static/lib/angucomplete-alt/angucomplete-alt.css`,
                `static/lib/ngTagsInput/ng-tags-input.min.css`
            ],
            scripts: [
                `static/lib/global/baseObject.js`,
                `static/lib/angucomplete-alt/angucomplete-alt.js`,
                `static/lib/ngTagsInput/ng-tags-input.min.js`
            ]
        }),
        new MergeJsonWebpackPlugin({
            "output": {
                "groupBy": [
                    {
                        "pattern": "./app/static/i18n/vi/*-vi.json",
                        "fileName": "./static/i18n/local-vi.json"
                    },
                    {
                        "pattern": "./app/static/i18n/en/*-en.json",
                        "fileName": "./static/i18n/local-en.json"
                    }
                ]
            }
        }),
        // new webpack.optimize.UglifyJsPlugin({
        //     minimize: true,
        //     sourceMap: true,
        //     compress: {
        //         warnings: false,
        //         keep_fnames: true
        //     },
        //     mangle: {
        //         except: ['$super', '$', 'exports', 'require', 'angular', '$q'],
        //         keep_fnames: true //it works
        //     }
        // }), // Minimize
        new WebpackAutoInject({
            PACKAGE_JSON_PATH: './package.json',
            SILENT: true,
            components: {
                AutoIncreaseVersion: true,
                InjectAsComment: true,
                InjectByTag: true
            },
            componentsOptions: {
                AutoIncreaseVersion: {
                    runInWatchMode: false // it will increase version with every single build!
                },
                InjectAsComment: {
                    tag: 'Build version: {version} - {date}' // default 
                }
            }
        })
    ]
}