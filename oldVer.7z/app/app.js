"use strict";

import angular from 'angular';
import uirouter from 'angular-ui-router';
import 'ui-select/dist/select.min.js';
import 'ui-select/dist/select.min.css';

import './app.import';
import Common from './common';
import Components from './components';
var n124 = angular.module('n124', ['ui.router', 'ui.tree', 'ngSanitize', 'pascalprecht.translate', 'uiSwitch', 'ngTagsInput', 'angucomplete-alt', 'mgcrea.ngStrap', 'angular.filter', 'ngAnimate', 'ui-notification', 'ngStorage', 'app.common', 'app.components', 'ui.tinymce', 'ui.select', 'ngSanitize','ngFileUpload']);
n124.config(function ($datepickerProvider, $typeaheadProvider) {
    angular.extend($datepickerProvider.defaults, {
        dateFormat: 'dd/MM/yyyy',
        modelDateFormat: 'dd/MM/yyyy HH:mm:ss',
        dateType: 'string'
    });
    angular.extend($typeaheadProvider.defaults, {
        animation: 'am-flip-x',
        minLength: 1,
        trimValue: true,
        template: 'typeahead/domain.account.tpl.html',
        delay: { show: 100, hide: 100000 }
    });
});
n124.run(function ($rootScope, $config, $helper, $http, $location, $filter, Notification) {

    // Config root $app
    $rootScope.location = $location;
    $rootScope.$app = {};
    $rootScope.$app = $config;

    $helper.ckLogin();

    var timeRand = new Date().getTime();

    $http.get(`${$config.BASE_URL}/static/menu/n124.menu.json?r=${timeRand}`).then(
        (done) => {
            localStorage.setItem('n124Menu', JSON.stringify(done.data));
        },
        (error) => { }
    );

    // check offline internet
    $(window).on('online offline', function () {
        $rootScope.$broadcast('eventDisconnect', { isDisconnect: !navigator.onLine });
    });

    $rootScope.$on('$stateChangeStart', function (event, toState) {
        $rootScope.$app.title = toState.data.name;
        $helper.ckLogin();
    });

    $rootScope.$on('$viewContentLoaded', function (event) {
        $helper.heightUi();
    });

    $rootScope.$on('handleErrorFromServer', function (event, data) {
        if (data) {
            Notification.error({
                message: `<u>${$filter('translate')('SYSTEM.TITLE.ERROR')}</u>: ${$filter('translate')(`SYSTEM.ERROR.${data.code}`)}`,
                delay: 5000,
                positionY: 'bottom',
                positionX: 'left'
            });
        }
    });
});