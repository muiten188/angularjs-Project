// Import bootstrap
import 'bootstrap/dist/css/bootstrap.css';

// Import font
import 'font-awesome/css/font-awesome.css';

// Admin LTE
import 'admin-lte/dist/css/skins/_all-skins.css';
import 'admin-lte/dist/css/AdminLTE.css';

// Import customer
import './static/css/default.skin-light.css';
import './static/css/index.css';
import './static/css/animate.css';

import 'angular-ui-notification/dist/angular-ui-notification.min.css';
import 'angular-ui-tree/dist/angular-ui-tree.min.css';