export default function () {
    return function (statusId) {
        var colourMap = {
            "ACTIVE": "bg-green",
            "INACTIVE": "bg-red",
             "WARNING": "bg-yellow"
        };
        if (colourMap[statusId]) {
            return colourMap[statusId];
        } else {
            return 'bg-green'
        }
    }
}