'use strict';

import UnSafe from './unsafe';
import BgrMethod from './bgrMethod';
import BgrRepeater from './bgrRepeater';
import HighLight from './high-light';

export default angular.module('app.filter', [])
    .filter('unsafe', ['$sce', UnSafe])
    .filter('bgrMethod', BgrMethod)
    .filter('highlight', ['$sce', HighLight])
    .name;