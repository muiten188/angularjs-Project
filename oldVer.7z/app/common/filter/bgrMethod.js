export default function () {
    return function (statusId) {
        var colourMap = {
            "POST": "bg-green",
            "GET": "bg-blue",
            "PUT": "bg-yellow",
            "PATCH": "bg-yellow",
            "DELETE": "bg-red",
        };
        if (colourMap[statusId]) {
            return colourMap[statusId];
        } else {
            return 'bg-yellow'
        }
    }
}