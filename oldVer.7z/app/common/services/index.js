'use strict';

// import N124Service from './n124.service';

export default angular.module('app.services', [])
    // .service('N124Service', N124Service)
    .name;