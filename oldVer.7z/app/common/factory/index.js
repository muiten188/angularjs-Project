'use strict';

import N124API from './n124.factory';
import N124BaseDialog from './baseDialog.factory';
import N124FileReader from './fileReader.factory';
import HelperModule from './helper.provider';

export default angular.module('app.factory', [])
    .factory('$api', N124API)
    .factory('$dialog', N124BaseDialog)
    .factory('$fileReader', N124FileReader)
    .provider('$helper', [HelperModule])
    .name;