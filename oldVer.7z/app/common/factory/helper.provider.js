'use strict';

export default function HelperModule() {
    return {
        $get: ['$rootScope', '$config', '$filter', function ($rootScope, $config, $filter) {

            var Helper = {

                isRemember: () => {
                    return localStorage.getItem('n124_RemeberMe');
                },

                user: () => {
                    if (Helper.isRemember() === 'true') {
                        return JSON.parse(localStorage.getItem('n124User'))
                    } else {
                        return JSON.parse(sessionStorage.getItem('n124User'))
                    }
                },

                ckLogin: () => {
                    var $user = Helper.user();
                    if (!_.isNull($user)
                        && !_.isUndefined($user)
                        && !_.isUndefined($user.jsessionId)
                        && !_.isUndefined($user.userName)) {
                        $rootScope.$app.logined = true;
                    } else {
                        $rootScope.$app.logined = false;
                    }
                    $rootScope.$broadcast('eventRefreshUser');
                },

                heightUi: () => {
                    //Get window height and the wrapper height
                    var neg = $('.main-header').outerHeight() + $('.main-footer').outerHeight();
                    var window_height = $(window).height();
                    var sidebar_height = $(".sidebar").height();

                    //Set the min-height of the content and sidebar based on the
                    //the height of the document.
                    if ($("body").hasClass("fixed")) {
                        $(".content-wrapper, .right-side").css('min-height', window_height - $('.main-footer').outerHeight());
                    } else {
                        var postSetWidth;
                        if (window_height >= sidebar_height) {
                            $(".content-wrapper, .right-side").css('min-height', window_height - neg);
                            postSetWidth = window_height - neg;
                        } else {
                            $(".content-wrapper, .right-side").css('min-height', sidebar_height);
                            postSetWidth = sidebar_height;
                        }
                    }
                },

                logout: () => {
                    $rootScope.$broadcast('eventLogout');
                },

                download: (inputData, fileName) => {
                    var blob = new Blob([inputData], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
                    var objectUrl = URL.createObjectURL(blob);
                    var anchorDownload = document.createElement('a');
                    anchorDownload.href = objectUrl;
                    anchorDownload.download = fileName;
                    anchorDownload.click();
                    URL.revokeObjectURL(anchorDownload.href);
                },

                makeId: (length) => {
                    var text = "";
                    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

                    for (var i = 0; i < (length || 5); i++)
                        text += possible.charAt(Math.floor(Math.random() * possible.length));

                    return text;
                },

                parseObject2Form: (object, transform) => {
                    var fd = new FormData();
                    for (var key in object) {
                        var item = object[key];
                        if (transform && transform.from && transform.from.indexOf(key) >= 0) {
                            var index = transform.from.indexOf(key);
                            key = transform.to[index];
                        }
                        if (typeof item !== 'object' || (item && item.constructor.name === 'File')) {
                            if (!angular.isUndefined(item) && item !== null && item != '') {
                                fd.append(key, item);
                            }
                        }
                        if (item && typeof item === 'object' && item.length > 0) {
                            for (var i = 0; i < item.length; i++) {
                                var child = item[i];
                                for (var keyChild in child) {
                                    var childValue = child[keyChild];
                                    if (transform && transform.from && transform.from.indexOf(keyChild) >= 0) {
                                        var index = transform.from.indexOf(keyChild);
                                        keyChild = transform.to[index];
                                    }
                                    if (!angular.isUndefined(childValue) && childValue !== null && childValue != '') {
                                        fd.append(`${key}[${i}].${keyChild}`, childValue);
                                    }
                                }
                            }
                        }
                    }
                    return fd;
                }
            };

            return Helper;
        }]
    };
}