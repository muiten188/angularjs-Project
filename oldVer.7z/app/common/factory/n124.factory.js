'use strict';

N124API.$inject = ['$rootScope', '$http', '$config', '$filter'];
export default function N124API($rootScope, $http, $config, $filter) {

    var handleRequestURL = function (url, $params, __idDisplay) {

        if (__idDisplay) {
            $rootScope.$broadcast('startStatusBar', {
                id: __idDisplay,
                icon: 'fa fa-spinner fa-spin',
                message: 'SYSTEM.NOTIFICATION.LOADING',
                text: '',
                isShow: true
            });
        }

        if (angular.isDefined($params) && angular.isObject($params) && $params.constructor.name !== 'FormData') {
            for (var key in $params) {
                if (
                    angular.isUndefined($params[key]) ||
                    $params[key] === null ||
                    (typeof ($params[key]) === 'string' && $params[key] === '') ||
                    (key === 'currentPage' && $params[key] === 0) ||
                    (key === 'pageSize' && $params[key] === 0)
                ) {
                    delete $params[key];
                }
            }
        }

        return {
            url: $params['fake'] ? url : ($config.BASE_URL_API + url),
            params: $params
        };
    };

    var handleResponse = function (response, params, __idDisplay) {
        $rootScope.$broadcast('eventDisconnect', { isDisconnect: false });
        if (angular.isDefined(response.data) && __idDisplay) {
            $rootScope.$broadcast('endStatusBar', { id: __idDisplay, data: response.data });
        }
        if (angular.isDefined(response.data) && angular.isObject(response.data)) {
            response.data.requestParams = params;
            return response.data;
        } else {
            if (angular.isDefined(response.data) && response.data != null) {
                return { data: response.data };
            } else {
                return { data: '' };
            }
        }
    }

    // Send list string : $.param(handle.params)

    return {
        URL: function(url) {
            return $config.BASE_URL_API + url;
        },
        get: function (url, params, __idDisplay, headers) {
            var handle = handleRequestURL(url, params, __idDisplay);
            var result = $http.get(handle.url, { params: handle.params }, headers)
                .then((response) => handleResponse(response, params, __idDisplay));
            return result;
        },
        post: function (url, params, __idDisplay, headers) {
            var handle = handleRequestURL(url, params, __idDisplay);
            // var result = $http.post(handle.url, $.param(handle.params), {})
            var result = $http.post(handle.url, handle.params, headers)
                .then((response) => handleResponse(response, params, __idDisplay));
            return result;
        },
        put: function (url, params, __idDisplay, headers) {
            var handle = handleRequestURL(url, params, __idDisplay);
            var result = $http.put(handle.url, handle.params, headers)
                .then((response) => handleResponse(response, params, __idDisplay));
            return result;
        },
        patch: function (url, params, __idDisplay) {
            var handle = handleRequestURL(url, params, __idDisplay);
            var result = $http.patch(handle.url, $.param(handle.params), {})
                .then((response) => handleResponse(response, params, __idDisplay));
            return result;
        },
        delete: function (url, params, __idDisplay) {
            var handle = handleRequestURL(url, params, __idDisplay);
            var result = $http.delete(handle.url, { data: handle.params, headers: { 'Content-Type': 'application/json' } })
                .then((response) => handleResponse(response, params, __idDisplay));
            return result;
        },
        export: function (url, params, __idDisplay) {
            var handle = handleRequestURL(url, params, __idDisplay);
            var result = $http.get(handle.url, { params: handle.params, responseType: 'arraybuffer' })
                .then((response) => handleResponse(response, params, __idDisplay));
            return result;
        },
        loadImage: function (url, params, __idDisplay) {
            var handle = handleRequestURL(url, params, __idDisplay);
            var result = $http.get(handle.url, { params: handle.params, responseType: 'blob' })
                .then((response) => handleResponse(response, params, __idDisplay));
            return result;
        },
        upload: function (url, params, __idDisplay) {
            var result = $http.post($config.BASE_URL_API + url, params,
                {
                    transformRequest: angular.identity,
                    headers: { 'Content-Type': undefined }
                })
                .then((response) => handleResponse(response, params, __idDisplay));
            return result;
        },
        uploadPut: function (url, params, __idDisplay) {
            var result = $http.put($config.BASE_URL_API + url, params,
                {
                    transformRequest: angular.identity,
                    headers: { 'Content-Type': undefined }
                })
                .then((response) => handleResponse(response, params, __idDisplay));
            return result;
        }
    }
}
