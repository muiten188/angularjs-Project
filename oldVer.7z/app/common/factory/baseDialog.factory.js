'use strict';

BaseDialog.$inject = ['$rootScope', '$modal', '$sce'];
export default function BaseDialog($rootScope, $modal, $sce) {

    var dialog = BaseObject.prototype.extend({
        modal: null,
        $scope: null,
        mdOptions: {
            title: 'SYSTEM.POPUP_MODAL.INFO.TITLE',
            type: 'modal-md',
            alertType: 'info',
            content: `<p>{{'SYSTEM.POPUP_MODAL.INFO.CONTENT' | translate}}</p>`,
            button: null,
            resolve: {}
        },
        construct: function (options) {
            options = options || {};
            this.$scope = options.$scope || $rootScope.$new();
            for (var option in options) {
                if (option != '$scope')
                    this[mdOptions] = options[option];
            }
            this.$scope.mdOptions = this.mdOptions;
        },
        open: function () {
            var self = this;
            self.modal = new $modal({
                scope: self.$scope,
                backdropClick: true,
                templateUrl: 'modal/modal.popup.tpl.html',
                show: true,
                animation: 'am-fade-and-scale',
                placement: 'center',
                resolve: self.resolve,
                keyboard: true
            })
            self.modal.$promise.then(self.modal.show);
        },
        close: function () {
            this.modal.hide();
        }
    });

    return dialog;
}
