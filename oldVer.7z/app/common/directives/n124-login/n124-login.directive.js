import '../../../static/css/authen.css';
import { N124LoginService } from './n124-login.service.js';

export default function N124Login($rootScope, $config, $helper, $api, $interval, $dateFilter, $state, Notification, $localStorage) {

    var stopTime;

    var loginService = new N124LoginService($api);

    //define the directive object
    var directive = {};

    //restrict = E, signifies that directive is Element directive
    directive.restrict = 'EA';

    //template replaces the complete element with its text. 
    directive.template = require('./n124-login.tpl.html');

    //scope is used to distinguish each student element based on criteria.
    directive.scope = true;

    //compile is called during application initialization. AngularJS calls it once when html page is loaded.

    directive.compile = function (element, attributes) {

        element.focus();

        //linkFunction is linked with each element with scope to get the element specific data.
        var linkFunction = function ($scope, element, attributes) {

            $scope.timer = new Date().getTime();
            $scope.timeGlobalDisplay = 'Loading time...';
            $scope.imageCaptcha = '';
            $scope.showCaptcha = false;

            $scope.login = () => {
                login();
            }

            $scope.generatecaptcha = () => {
                generatecaptcha();
            }

            $scope.isDisconnect = false;
            $rootScope.$on('eventDisconnect', function (event, args) {
                $scope.isDisconnect = args.isDisconnect;
            });

            var interval = attributes.interval || 1000;

            var updateTime = () => {
                $scope.timer = $scope.timer + parseInt(interval, 10);
                $scope.dateGlobalDisplay = $dateFilter($scope.timer, 'EEEE, MMMM d, y');
                $scope.timeGlobalDisplay = $dateFilter($scope.timer, 'HH:mm:ss');
            }

            stopTime = $interval(updateTime, interval);

            element.on('$destroy', function () {
                $interval.cancel(stopTime);
            });

            var setDefault = () => {
                $scope.frm = {
                    username: '',
                    password: '',
                    captcha: null,
                    rememberMe: false
                }
            }

            setDefault();

            var generatecaptcha = () => {
                loginService.generatecaptcha({}).then(function (response) {
                    $scope.imageCaptcha = URL.createObjectURL(response);
                }, function (error) {
                    $scope.imageCaptcha = null;
                });
            }

            var login = () => {

                // clear storage
                sessionStorage.removeItem('n124User');
                localStorage.removeItem('n124User');

                loginService.login({
                    username: $scope.frm.username,
                    password: $scope.frm.password,
                    captcha: $scope.frm.captcha
                }).then(function (response) {

                    delete response['requestParams'];

                    localStorage.setItem('n124_RemeberMe', $scope.frm.rememberMe);
                    if ($scope.frm.rememberMe) {
                        localStorage.setItem('n124User', JSON.stringify(response));
                    } else {
                        sessionStorage.setItem('n124User', JSON.stringify(response));
                    }

                    window.location.reload();

                }, function (error) {
                    if (error.data.message.toLocaleLowerCase().indexOf('captcha') != -1) {
                        generatecaptcha();
                        $scope.showCaptcha = true;
                    }
                });
            }

            function getRandomColor() {
                var letters = '0123456789ABCDEF';
                var color = '#';
                for (var i = 0; i < 6; i++) {
                    color += letters[Math.floor(Math.random() * 16)];
                }
                return color;
            }

        }
        return linkFunction;
    }
    return directive;
}