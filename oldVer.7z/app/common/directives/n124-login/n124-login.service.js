export class N124LoginService {

    constructor($api) {
        this.$inject = ['$api']; this.$api = $api;
    }

    login(params) {
        return this.$api.post(
            'authentication/login', params
        );
    }

    logout(params) {
        return this.$api.get(
            'authentication/logout', params
        );
    }

    generatecaptcha(params) {
        return this.$api.loadImage(
            'authentication/captcha/', params
        );
    }
}