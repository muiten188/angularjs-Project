export default function UploadFile( $parse, $config) {
    //define the directive object
    var directive = {};

    //restrict = E, signifies that directive is Element directive
    directive.restrict = 'EA';
 
    //template replaces the complete element with its text. 
    // directive.template = require('./upload-file.tpl.html');

    //scope is used to distinguish each student element based on criteria.
    directive.scope =true;
    

    //compile is called during application initialization. AngularJS calls it once when html page is loaded.

    directive.compile = function (element, attributes) {

        //linkFunction is linked with each element with scope to get the element specific data.
        var linkFunction =
         function(scope, element, attrs) {
                  var model = scope.uploadFile;
                  var modelSetter = model.assign;
                  element.bind('change', function(){
                     scope.$apply(function(){
                        // modelSetter(scope, element[0].files[0]);
                         if (element[0].files != undefined) {
                        //   fileService.push(element[0].files[0]);
                    }
                     });
                  });
               }
        return linkFunction;
    }
    return directive;
}