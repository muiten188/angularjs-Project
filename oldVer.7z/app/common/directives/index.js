'use strict';

import HeaderApp from './header/header.directive';
import FooterApp from './footer/footer.directive';
import SidebarLeftApp from './sidebar-left/sidebar-left.directive';
import SidebarRightApp from './sidebar-right/sidebar-right.directive';
import TemplateCached from './template-cached/templateCached.directive';
import N124Table from './n124-table/n124-table.directive';
import N124Pagging from './n124-pagging/n124-pagging.directive';
import N124BreadCrumb from './n124-breadcrumb/n124-breadcrumb.directive';
import N124Login from './n124-login/n124-login.directive';
import RoleTreeView from './role-treeview/role-treeview.directive';
import N124Permission from './n124-permission/n124-permission.directive';
import N124Include from './n124-include/n124-include.directive';
import N124Validation from './n124-validation/n124-validation.directive';
import CompileHtml from './compile-html/compile-html.directive';
import FilesInput from './files-input/files-input.directive';
import UploadFile from './upload-file/upload-file.directive';
import ToNumber from './to-number/to-number.directive';
import DepartmentTree from './department-tree/department-tree.directive';

export default angular.module('app.directives', [])
    .directive('compile', ['$compile', CompileHtml])
    .directive('headerApp', ['$rootScope', '$api', '$config', '$helper', '$localStorage', '$translate', HeaderApp])
    .directive('footerApp', ['$rootScope', '$api', '$config', FooterApp])
    .directive('sidebarLeft', ['$rootScope', '$api', '$config', '$http', SidebarLeftApp])
    .directive('siderbarRight', SidebarRightApp)
    .directive('templateCached', TemplateCached)
    .directive('n124Table', ['$rootScope', '$config', '$filter', N124Table])
    .directive('n124Pagging', ['$config', N124Pagging])
    .directive('n124BreadCrumb', ['$rootScope', '$config', N124BreadCrumb])
    .directive('roleTreeView', ['$rootScope', '$config', '$interpolate', RoleTreeView])
    .directive('n124Permission', ['$rootScope', '$config', N124Permission])
    .directive('n124Include', ['$rootScope', '$config', N124Include])
    .directive('n124Validation', ['$rootScope', '$config', '$compile', '$filter', N124Validation])
    .directive('n124Login', ['$rootScope', '$config', '$helper', '$api', '$interval', 'dateFilter', '$state', 'Notification', '$localStorage', N124Login])
    .directive('filesInput', FilesInput)
    .directive('uploadFile', ['$parse', '$config', UploadFile])
    .directive('toNumber', ToNumber)
    .directive('departmentTree', ['$rootScope', '$config', DepartmentTree])
    .name;