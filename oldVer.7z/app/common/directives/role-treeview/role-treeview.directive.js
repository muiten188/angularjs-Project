export default function RoleTreeView($rootScope, $config, $interpolate) {
    //define the directive object
    var directive = {};

    directive.require = "ngModel";
    //restrict = E, signifies that directive is Element directive
    directive.restrict = 'EA';
    directive.replace = true;

    //template replaces the complete element with its text. 
    directive.template = require('./role-treeview.tpl.html');

    //scope is used to distinguish each student element based on criteria.
    directive.scope = {
        list: '=?',
        isOpen: '=?'
    };

    directive.link = function ($scope, element, attributes, ngModel) {

        $scope.tree = _.groupBy($scope.list, attributes.fieldGroup);
        $scope.group = [];
        $scope.child = [];
        $scope.root = false;

        // update data to view
        ngModel.$formatters.push(function (modelValue) {
            if (modelValue) {
                $scope.lstCheck = modelValue;
            }
            return modelValue;
        });

        $scope.$watch(
            'lstCheck',
            () => {
                $scope.check();
                ngModel.$setViewValue($scope.lstCheck);
            },
            true
        )

        $scope.check = function (type, keyId, childId) {
            switch (type) {
                case 'root':
                    $scope.root = !$scope.root;
                    for (var i in $scope.group) {
                        $scope.group[i] = $scope.root;
                        for (var m in $scope.child[i]) {
                            $scope.child[i][m] = $scope.root;
                            $scope.check('child', i, m);
                        }
                    }
                    break;
                case 'group':
                    for (var m in $scope.child[keyId]) {
                        $scope.child[keyId][m] = $scope.group[keyId];
                        $scope.check('child', keyId, m);
                    }
                    break;
                case 'child':
                    if ($scope.child[keyId][childId] === true) {
                        if (_.indexOf($scope.lstCheck, parseInt(childId)) < 0)
                            $scope.lstCheck.push(parseInt(childId))
                    } else {
                        var index = _.indexOf($scope.lstCheck, parseInt(childId));
                        $scope.lstCheck.splice(index, 1);
                    }
                    break;
                default:
                    for (var i in $scope.tree) {
                        $scope.group[i] = false;
                        $scope.child[i] = [];
                        var c = 0;
                        for (var k in $scope.tree[i]) {
                            var functionId = $scope.tree[i][k][attributes.fieldId];
                            if ($scope.lstCheck.indexOf(parseInt(functionId)) >= 0) {
                                c++;
                                $scope.child[i][functionId] = true;
                            } else {
                                $scope.child[i][functionId] = false;
                            }
                        }
                        if ($scope.tree[i].length === c) {
                            $scope.root = true;
                            $scope.group[i] = true;
                        } else {
                            $scope.root = false;
                        }
                    }
                    break;
            }
        }
    }

    return directive;
}