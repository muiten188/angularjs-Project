import { N124ValidationService } from './n124-validation.service.js';

export default function N124Validation($rootScope, $config, $compile, $filter) {

    var directive = {};
    var template = require('./n124-validation.tpl.html');

    directive.restrict = 'AE';
    directive.require = '^?form';

    directive.scope = {
        nameInput: '=?',
        errorIn: '=?',
    };

    directive.compile = function (element) {

        return function (scope, el, attrs, formCtrl) {
            scope.errorIn = scope.errorIn || 'input';
            scope.nameInput = scope.nameInput || el.find('input').attrs('name');

            if (formCtrl) {
                scope.inputElement = formCtrl[scope.nameInput];
                if (scope.inputElement) {
                    scope.$watch(function () {
                        return scope.inputElement.$dirty && scope.inputElement.$invalid;
                    }, (newValue) => {
                        if (scope.inputElement.$dirty && scope.inputElement.$invalid) {
                            el.find(scope.errorIn).addClass('error-hightline animated shake');
                        } else {
                            el.find(scope.errorIn).removeClass('error-hightline animated shake');
                        }
                    });
                }
            }

            // Gan scope chi voi template nay
            var tmp = angular.element(template);
            el.append($compile(tmp)(scope));

        };
    }

    return directive;
}