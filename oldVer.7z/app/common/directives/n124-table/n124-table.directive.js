export default function N124Table($rootScope, $config, $filter) {

    //define the directive object
    var directive = {};

    //restrict = E, signifies that directive is Element directive
    directive.restrict = 'EA';

    //template replaces the complete element with its text. 
    directive.template = require('./n124-table.tpl.html');

    //scope is used to distinguish each student element based on criteria.
    directive.scope = {
        controller: "=controller",
        gridOptions: "=", // get object
        pageOptions: "=",
        codePermission: "=?",
        sortType: "@", // set the default sort type
        sortReverse: "=", // set the default sort order
        searchKey: "@", // set the default search/filter term
        showSearch: "=?" // set the default search/filter term
    }

    directive.controller = ['$scope', ($scope) => {

    }];

    //compile is called during application initialization. AngularJS calls it once when html page is loaded.

    directive.compile = function (element, attributes) {

        //linkFunction is linked with each element with scope to get the element specific data.
        var linkFunction = function ($scope, element, attributes) {            

            if (angular.isUndefined($scope.showSearch)) {
                $scope.showSearch = false;
            }

            $rootScope.$on('startStatusBar', function (event, args) {
                if (args.id == 'table') {
                    $scope.statusBar = args;
                }
            });

            $rootScope.$on('endStatusBar', function (event, args) {
                if (args.id == 'table') {
                    if (args.data.totalPage == 0 && args.data.data.length == 0) {
                        $scope.statusBar = {
                            icon: 'fa fa-meh-o',
                            message: 'SYSTEM.NOTIFICATION.NO_RECORD',
                            text: 'padding-10',
                            isShow: true
                        }
                    } else {
                        $scope.statusBar = {
                            isShow: false
                        }
                    }
                }
            });

        }
        return linkFunction;
    }
    return directive;
}