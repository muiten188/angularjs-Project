export default function N124Permission($rootScope, $config) {
    //define the directive object
    var directive = {};

    //restrict = E, signifies that directive is Element directive
    directive.restrict = 'A';

    //template replaces the complete element with its text. 
    directive.template = require('./n124-permission.html');

    //scope is used to distinguish each student element based on criteria.
    directive.scope = {
        n124Permission: '='
    };

    //compile is called during application initialization. AngularJS calls it once when html page is loaded.

    directive.compile = function (element, attributes) {

        //linkFunction is linked with each element with scope to get the element specific data.
        var linkFunction = function ($scope, element, attributes) {
            var $user = JSON.parse(localStorage.getItem('n124User'));
            if (angular.isDefined($scope.n124Permission)) {
                var _type = $scope.n124Permission.split(":")[0];
                var _code = $scope.n124Permission.split(":")[1];
                switch (_type) {
                    case "page":
                        // var $item = _.find($user.listRoleGroup, (value) => { return value === _code; });
                        // if (angular.isUndefined($item)) {
                        //     element.html("<section style='font-size: 25px;text-align: center;' class='content'>😱 Bạn không có quyền truy cập trang này !</section>");
                        // }
                        break;
                    case "menu":
                        // var $item = _.find($user.listRoleGroup, (value) => { return value === _code; });
                        // if (angular.isUndefined($item)) {
                            // element.css('display', "none");
                        // } else {
                            // element.css('display', "block");
                        // }
                        break;
                    case "btn":
                        // var $item = _.find($user.listRoleCode, (value) => { return value === _code; });
                        // if (angular.isUndefined($item)) {
                        //     element.attr('disabled', "disabled");
                        //     element.on('click', function ($event) {
                        //         $event.stopPropagation();
                        //         $event.preventDefault();
                        //     });
                        // } else {
                            element.removeAttr('disabled');
                        // }
                        break;
                    case "table":
                        // var $item = _.find($user.listRoleCode, (value) => { return value === _code; });
                        // if (angular.isUndefined($item)) {
                        //     element.remove();
                        // }
                        break;
                }
            }
        }
        return linkFunction;
    }
    return directive;
}
