export default function N124Include($rootScope, $config) {
    //define the directive object
    var rootDir = './../../../';

    var directive = {};

    //restrict = E, signifies that directive is Element directive
    directive.restrict = 'EA';

    //template replaces the complete element with its text. 
    directive.templateUrl = ('./../../../static/template/employee/general.html');
    
    //scope is used to distinguish each student element based on criteria.
    directive.scope = {
        n124Include: '=?'
    };

    //compile is called during application initialization. AngularJS calls it once when html page is loaded.
    directive.link = function ($scope, element, attributes) {
        directive.templateUrl = ('./../../../static/template/employee/general.html');
    }

    directive.compile = function (element, attributes) {
        return function ($scope, element, attributes) {

            // element.html(rootDir + $scope.n124Include);
        }
    }

    return directive;
}
