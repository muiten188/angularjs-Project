export default function N124Pagging($config) {
    //define the directive object
    var directive = {};

    //restrict = E, signifies that directive is Element directive
    directive.restrict = 'EA';

    //template replaces the complete element with its text. 
    directive.template = require('./n124-pagging.tpl.html');

    //scope is used to distinguish each student element based on criteria.
    directive.scope = {
        pageOptions: "=?",
        codePermission: "=?",
        funcChange: "&fnChange", // set the default sort type
    }

    //compile is called during application initialization. AngularJS calls it once when html page is loaded.

    directive.compile = function (element, attributes) {

        //linkFunction is linked with each element with scope to get the element specific data.
        var linkFunction = function ($scope, element, attributes) {

            var paggingPrivate = new _N124Pagging();

            // set default
            $scope.listPageSizeDefault = angular.copy($config.LIST_PAGE_SIZE)

            if (!$scope.pageOptions) {
                $scope.pageOptions = angular.copy($config.PAGE_OPTIONS);
            }

            // watchdog data change
            $scope.$watch('pageOptions', function (newValue, oldValue) {
                if (newValue){
                    $scope.pageOptions = newValue;
                    createPagging();
                }
            });

            // create pagging then get config from page call it.
            var createPagging = () => {
                if (angular.isUndefined($scope.pageOptions.totalPage) || $scope.pageOptions.totalPage <= 1) {
                    $scope.showPagging = false;
                } else {
                    $scope.showPagging = true;
                    $scope.getNumber = () => { return paggingPrivate.getNumber($scope.pageOptions.totalPage); }
                    paggingPrivate.checkNextPrev($scope);
                }
            }

            $scope.reSize = () => {
                $scope.pageOptions.currentPage = 1;
                $scope.funcChange();
            }

            $scope.changePage = (currentPage) => {
                if (typeof ($scope.funcChange) === 'function') {
                    $scope.pageOptions.currentPage = currentPage;
                    $scope.funcChange();
                } else {
                    console.error("Not have function 'changePage'");
                }
            }

            $scope.nextPage = () => {
                if (typeof ($scope.funcChange) === 'function') {
                    if ($scope.pageOptions.currentPage < $scope.pageOptions.totalPage) {
                        $scope.pageOptions.currentPage++;
                        $scope.funcChange();
                    }
                } else {
                    console.error("Not have function 'changePage'");
                }
            }
            $scope.prevPage = () => {
                if (typeof ($scope.funcChange) === 'function') {
                    if ($scope.pageOptions.currentPage > 1) {
                        $scope.pageOptions.currentPage--;
                        $scope.funcChange();
                    }
                } else {
                    console.error("Not have function 'changePage'");
                }
            }

        }
        return linkFunction;
    }
    return directive;
}

class _N124Pagging {
    getNumber(num) {
        return new Array(num);
    }
    checkNextPrev($scope) {
        if ($scope.pageOptions.currentPage < $scope.pageOptions.totalPage) {
            $scope.isDisableButtonNext = false;
        } else {
            $scope.isDisableButtonNext = true;
        }
        if ($scope.pageOptions.currentPage > 1) {
            $scope.isDisableButtonPrev = false;
        } else {
            $scope.isDisableButtonPrev = true;
        }
    }
}