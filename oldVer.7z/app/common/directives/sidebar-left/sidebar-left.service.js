export class SidebarLeftService {

    constructor($api) {
        this.$inject = ['$api']; this.$api = $api;
    }

    getNumRepeater(params) {
        return this.$api.get(
            'repeaters/reportDashboard/', params
        );
    }
}