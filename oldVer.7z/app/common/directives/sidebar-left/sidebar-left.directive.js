import { SidebarLeftService } from './sidebar-left.service';

class SidbarLeftPrivate {

    constructor($scope, $api) {
        this.$inject = ['$api']; this.$api = $api;
        this.$scope = $scope;
        this.$sidebarLeftAPI = new SidebarLeftService($api);
    }

    getNumRepeater() {
        this.$sidebarLeftAPI.getNumRepeater({}).then(
            (done) => {
                this.$scope.dashboard = {
                    active: done.totalInactive,
                    toltal: done.total
                }
            },
            (error) => { }
        );
    }
}

export default function SidebarLeftApp($rootScope, $api, $config, $http) {
    //define the directive object
    var directive = {};

    //restrict = E, signifies that directive is Element directive
    directive.restrict = 'EA';

    //template replaces the complete element with its text. 
    directive.template = require('./sidebar-left.html');

    //scope is used to distinguish each student element based on criteria.
    directive.scope = {
        page: "@page"
    }

    //compile is called during application initialization. AngularJS calls it once when html page is loaded.

    directive.compile = function (element, attributes) {
        //linkFunction is linked with each element with scope to get the element specific data.
        var linkFunction = function ($scope, element, attributes) {

            $scope.menus = JSON.parse(localStorage.getItem('n124Menu'));

            // get number repeater active in toltal
            // var $sidebarLeft = new SidbarLeftPrivate($scope, $api);

            // $sidebarLeft.getNumRepeater();

            // setInterval(function () {
            //     $sidebarLeft.getNumRepeater();
            // }, $config.INTERVAL.MENU_DASHBOARD);

        }
        return linkFunction;
    }
    return directive;
}