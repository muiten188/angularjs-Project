export default function DepartmentTree($rootScope, $config) {
    //define the directive object
    var directive = {};

    //restrict = E, signifies that directive is Element directive
    directive.restrict = 'EA';

    //template replaces the complete element with its text. 
    directive.template = require('./department-tree.tpl.html');

    //scope is used to distinguish each student element based on criteria.
    directive.scope = {
        list: '=?list',
        value: '=',
        readOnly: '=',
        isOpen: '='
    };

    directive.transclude = true;

    directive.replace = true;

    directive.compile = function (element, attributes) {
        var linkFn = function ($scope, element, attributes) {

            var list = angular.copy($scope.list);

            if (attributes.fieldId && attributes.fieldGroup) {
                var id = attributes.fieldId;
                var parentId = attributes.fieldGroup;
                var showName = attributes.fieldShow;

                // Build tree with lodash
                var map = {}, node, roots = [], i;
                for (i = 0; i < list.length; i += 1) {
                    map[list[i][id]] = i;
                    list[i].sub = [];
                }
                for (i = 0; i < list.length; i += 1) {
                    node = list[i];
                    if (node.parentId !== null) {
                        list[map[node[parentId]]].sub.push(node);
                    } else {
                        roots.push(node);
                    }
                }

                $scope.sendId = function (Id) {
                    if (!$scope.readOnly) {
                        if (Id) {
                            var item = $scope.list.filter((item) => {
                                return item[id] === Id;
                            })[0];
                            $rootScope.$broadcast("IdTreeView", item);
                        }
                    }
                }

                var draw = function (item) {

                    if (angular.isArray(item) && item.length === 1) {
                        item = item[0];
                    }

                    var isSelected = '';
                    if (item[id] == $scope.value)
                        isSelected = 'isSelected';

                    var html = `
                        <li>
                            <i class="indicator glyphicon glyphicon-folder-open"></i>
                            <a ng-dblclick="sendId(${item[id]})" data-toggle="collapse" data-target="#parent_${item[id]}" class="collapsed ${isSelected}">${item[showName]}</a>
                    `;
                    if (item && item.sub && item.sub.length > 0) {
                        html += `<ul class="collapse" id="parent_${item[id]}" ng-class="(isOpen ? 'in':'')">`;
                        item.sub.forEach((sub) => {
                            html += draw(sub);
                        })
                        html += `</ul>`;
                    }
                    html += '</li>';
                    return html;
                }

                if (roots && roots.length > 0) {
                    $scope.contentTree = draw(roots);
                }

            }
        }
        return linkFn;
    }
    return directive;
}
