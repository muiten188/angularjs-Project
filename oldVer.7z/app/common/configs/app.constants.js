'use strict';

const conf = require('../../../env.js');

class ConstantsModule {
    constructor() {
        this.$config = {
            VERSION: "1.0.0",
            DEBUG: true,
            APP_TITLE: "Hapulico",
            APP_NAME: "Hapulico",
            BASE_URL: `//${window.location.host}${conf.PUCLIC_PATH}`,
            BASE_URL_API: conf.BASE_URL_API,

            INTERVAL: {
                MENU_DASHBOARD: 1500,
                DASHBOARD: 15000,
            },

            PAGE_OPTIONS: {
                totalPage: 0,
                pageSize: 10,
                currentPage: 1
            },

            DATE_FORMAT: "dd/MM/yyyy HH:mm:ss",
            DATE_FORMAT_SHORT: "dd/MM/yyyy",

            LIST_PAGE_SIZE: [
                { label: '5', value: 5 },
                { label: '10', value: 10 },
                { label: '20', value: 20 },
                { label: '50', value: 50 },
                { label: '100', value: 100 }
            ],
            MENU: (_state, _method, _path) => {
                var group = _.where(JSON.parse(localStorage.getItem('n124Menu')), {
                    state: _state
                });
                // var items = _.find(group[0].api, (item) => {
                //     if (angular.isDefined(_path) && _path !== null) {
                //         return item.method === _method && item.path === _path;
                //     } else {
                //         return item.method === _method;
                //     }
                // });
                // if (items)
                //     return items.code;
                return '';
            },
            PAGE: (_state) => {
                var group = _.where(JSON.parse(localStorage.getItem('n124Menu')), {
                    state: _state
                });
                if (group && group[0])
                    return group[0].code;
                return '';
            },
            PAGECF: (_code) => {                
                var menuData = JSON.parse(localStorage.getItem('n124Menu'));
                var output;
                for (var i in menuData) {
                    var menu = menuData[i];
                    if (menu.code === _code) {
                        output = menu;
                        break;
                    }
                    if (menu.sub && menu.sub.length > 0) {
                        for (var k in menu.sub) {
                            var sub = menu.sub[k];
                            if (sub.code === _code) {
                                output = sub;
                                break;
                            }
                        }
                    }
                }

                return output ? output : {
                    code: _code,
                    state: _code,
                    url: '/',
                    name: 'Đăng nhập'
                };
            }
        };
    }
}

module.exports = new ConstantsModule();