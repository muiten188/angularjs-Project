'use strict';

const conf = require('../../../env.js');

i18nConfig.$inject = ['$translateProvider'];

export default function i18nConfig($translateProvider) {
    $translateProvider.useStaticFilesLoader({
        prefix: 'static/i18n/local-',
        suffix: '.json'
    });
    if (!angular.isString(localStorage.getItem('n124Lang'))) {
        localStorage.setItem("n124Lang", conf.LANGUAGE_CODE);
    }
    var langCode = localStorage.getItem("n124Lang");
    $translateProvider.preferredLanguage(langCode);
    $translateProvider.useSanitizeValueStrategy('sanitizeParameters');
}
