routing.$inject = ['$urlRouterProvider', '$locationProvider', '$httpProvider'];

export default function routing($urlRouterProvider, $locationProvider, $httpProvider) {
    // $locationProvider.html5Mode(true); // html5Mode
    $urlRouterProvider.otherwise('/');

    delete $httpProvider.defaults.headers.common['X-Requested-With'];
    $httpProvider.defaults.headers.common['Access-Control-Allow-Headers'] = 'X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method, Authorization';
    $httpProvider.defaults.headers.common['Access-Control-Allow-Origin'] = '*';
    $httpProvider.defaults.headers.common['Access-Control-Allow-Methods'] = 'GET,POST,PUT,HEAD,DELETE,OPTIONS';

    $httpProvider.defaults.headers.common['Accept'] = 'application/json, text/plain, */*';
    $httpProvider.defaults.headers.post['Content-Type'] = 'application/json; charset=utf-8';
    $httpProvider.defaults.headers.put['Content-Type'] = 'application/json; charset=utf-8';

    // $httpProvider.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded;charset=utf-8';
    // $httpProvider.defaults.headers.put['Content-Type'] = 'application/x-www-form-urlencoded;charset=utf-8';
    // $httpProvider.defaults.headers.patch['Content-Type'] = 'application/x-www-form-urlencoded;charset=utf-8';

    // $httpProvider.defaults.headers.common = {};
    // $httpProvider.defaults.headers.post = {};
    // $httpProvider.defaults.headers.put = {};
    // $httpProvider.defaults.headers.patch = {};

    $httpProvider.interceptors.push(['$rootScope', '$q', '$location', '$helper',
        function ($rootScope, $q, $location, $helper) {
            return {
                'request': function (config) {
                    if (config.url.indexOf('authentication') < 0 && config.url.indexOf('angular-ui-notification') < 0) {
                        var $user = $helper.user();
                        config.headers = config.headers || {};
                        var jsessionId = ($user !== null) ? $user.jsessionId : null;
                        var isEmpty = angular.isUndefined(jsessionId) || jsessionId === null || jsessionId.trim() === '';
                        if (!isEmpty) {
                            config.headers.JSESSIONID = $user.jsessionId;
                        } else {
                            $helper.logout();
                        }
                    }

                    // // set language code
                    // // var langCode = (angular.isDefined(localStorage.getItem('jLangCode')) && localStorage.getItem('jLangCode') != null) ? localStorage.getItem('jLangCode') : $config.SYSTEM_LANGUAGE;
                    // // config.headers['Accept-Language'] = langCode.replace('_', '-');

                    return config;
                },
                'responseError': function (response) {

                    if (
                        [401, 403].indexOf(response.status) >= 0
                        || (response.data && ['REQUEST_INVALID', 'REQUEST_SESSION_NOT_EXIST'].indexOf(response.data.code) >= 0)
                    ) {
                        $helper.logout();
                    }

                    if (response.status === -1) {
                        console.log('disconnect')
                        $rootScope.$broadcast('eventDisconnect', { isDisconnect: true });
                    } else {
                        console.log('connect')
                        $rootScope.$broadcast('eventDisconnect', { isDisconnect: false });
                        // handle error
                        $rootScope.$broadcast('handleErrorFromServer', response.data);
                    }

                    return $q.reject(response);
                }
            };
        }
    ]);
}