'use strict';

import ConstantsModule from './app.constants';
import RouterConfig from './app.router';
import i18nConfig from './app.i18n';

export default angular.module('app.configs',[])
.constant('$config', ConstantsModule.$config)
.config(RouterConfig)
.config(i18nConfig)
.name;