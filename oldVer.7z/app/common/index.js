'use strict';

import Configs from './configs';
import Services from './services';
import Factory from './factory';
import Filter from './filter';
import Directives from './directives';

export default angular.module('app.common', [Configs, Services, Factory, Filter, Directives]).name;