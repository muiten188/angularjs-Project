import { BuildingService } from './building.service';

let vm;
let config;

export default class BuildingController {

    constructor($config, $rootScope, $scope, $filter, $api, $helper, $state, $translate, $dialog, Notification) {

        this.$inject = ['$config', '$rootScope', '$scope', '$filter', '$api', '$helper', '$state', '$translate', '$dialog', 'Notification'];

        vm = this;
        config = $config;

        // permission
        $scope.menu = $config.MENU;
        $scope.stateName = $state.current.name;
        $scope.codePage = 'page:' + $config.PAGE($state.current.name);

        vm.$rootScope = $rootScope;
        vm.$scope = $scope;
        vm.$filter = $filter;
        vm.Noti5 = Notification;
        vm.$helper = $helper;
        vm.$dialog = $dialog;

        // connect service
        vm.$buildingApi = new BuildingService($api);

        vm.$scope.gridOptions = {
            header: [
                { headerHtml: vm.renderCheckbox, field: 'buildingId', css: "width: 5%; text-align:center;", func: vm.renderCheckList },
                { headerName: 'BUILDING.TABLE_HEADER.BUILDING_CODE', field: 'buildingCode', func: vm.renderBuilding },
                { headerName: 'BUILDING.TABLE_HEADER.ADDRESS', field: 'address' },
                { headerName: 'BUILDING.TABLE_HEADER.DESCRIPTION', field: 'description'},
                { headerName: 'BUILDING.TABLE_HEADER.NUMBER_FLOOR', field: 'numberFloor' }
            ],
            data: []
        }
        vm.$scope.pageOptions = angular.copy(config.PAGE_OPTIONS);

        vm.setDefault();
        vm.searchBuilding();
    }

    // render
    renderCheckbox() {
        return `<input type="checkbox" ng-model="controller.$scope.checkAll" ng-click="controller.toggleCheckAll()"/>`;
    }
    renderCheckList(rowItem) {
        return `<input ng-model="controller.$scope.listId[${rowItem.data.buildingId}]" ng-click="controller.toggleCheckItem(${rowItem.data.buildingId})" type="checkbox" />`
    }
    renderBuilding(rowItem) {
        return `<span class="href-link" ng-click="controller.chooseActions(${rowItem.data.buildingId})" ng-bind-html="'${rowItem.data.code}' | highlight:controller.$scope.frmSearch.code"></span>`;
    }
    toggleCheckAll() {
        vm.$scope.selectionId = [];
        vm.$scope.gridOptions.data.forEach((item) => {
            vm.$scope.listId[item.buildingId] = (vm.$scope.checkAll) ? true : false;
            if (vm.$scope.checkAll) vm.$scope.selectionId.push(item.buildingId);
        })
    }
    toggleCheckItem(buildingId) {
        if (buildingId) {
            var index = vm.$scope.selectionId.indexOf(buildingId);
            if (index < 0) {
                vm.$scope.selectionId.push(buildingId);
            } else {
                vm.$scope.selectionId.splice(index, 1);
            }
            vm.$scope.checkAll = (vm.$scope.selectionId.length >= vm.$scope.gridOptions.data.length) ? true : false;
        }
    }

    setDefault() {
        vm.$scope.checkAll = false;
        vm.$scope.listId = [];
        vm.$scope.selectionId = [];
        vm.$scope.frmSearch = {
            "code": "",
            "address": ""
        }
    }

    searchBuilding() {
        vm.$buildingApi.searchBuilding({
            "code": vm.$scope.frmSearch.code,
            "address": vm.$scope.frmSearch.address,
            "description": vm.$scope.frmSearch.description,
            "pageSize": vm.$scope.pageOptions.pageSize,
            "currentPage": vm.$scope.pageOptions.currentPage
        }).then(
            (result) => {
                vm.$scope.gridOptions.data = (result.data);
                vm.$scope.pageOptions = {
                    totalPage: result.totalPage,
                    pageSize: result.pageSize,
                    currentPage: result.currentPage
                };
            }
            );
    }

    createBuilding() {
        vm.$buildingApi.createBuilding(vm.$scope.frmModal).then(
            (result) => {
                vm.searchBuilding();
                vm.frm.close();
                vm.Noti5.success({
                    message: `<u>${vm.$filter('translate')('SYSTEM.TITLE.INFO')}</u>: ${vm.$filter('translate')('SYSTEM.NOTIFICATION.SUCCESS_ADD')}`,
                    delay: 5000,
                    positionY: 'bottom',
                    positionX: 'left'
                });
            });
    }

    updateBuilding() {
        vm.$buildingApi.updateBuilding(vm.$scope.frmModal).then(
            (result) => {
                vm.searchBuilding();
                vm.frm.close();
                vm.Noti5.success({
                    message: `<u>${vm.$filter('translate')('SYSTEM.TITLE.INFO')}</u>: ${vm.$filter('translate')('SYSTEM.NOTIFICATION.SUCCESS_UPDATE')}`,
                    delay: 5000,
                    positionY: 'bottom',
                    positionX: 'left'
                });
            });
    }

    deleteBuilding(buildingId) {
        vm.$buildingApi.deleteBuilding({
            $id: vm.$scope.buildingIdCached
        }).then(
            (result) => {
                vm.searchBuilding();
                vm.frmConfirm.close();
                vm.frm.close();
                vm.Noti5.success({
                    message: `<u>${vm.$filter('translate')('SYSTEM.TITLE.INFO')}</u>: ${vm.$filter('translate')('SYSTEM.NOTIFICATION.SUCCESS_DELETE')}`,
                    delay: 5000,
                    positionY: 'bottom',
                    positionX: 'left'
                });
            });
    }

    deleteBuildingMutil() {
        vm.$buildingApi.deleteBuildingMutil({
            ids: vm.$scope.selectionId
        }).then(
            (result) => {
                vm.searchBuilding();
                vm.frmConfirm.close();
                vm.frm.close();
                vm.Noti5.success({
                    message: `<u>${vm.$filter('translate')('SYSTEM.TITLE.INFO')}</u>: ${vm.$filter('translate')('SYSTEM.NOTIFICATION.SUCCESS_DELETE')}`,
                    delay: 5000,
                    positionY: 'bottom',
                    positionX: 'left'
                });
            });
    }

    chooseActions(buildingId) {
        if (buildingId && angular.isNumber(buildingId)) {
            vm.$buildingApi.getBuildingbyId({
                $id: buildingId
            }).then((result) => {
                vm.$scope.frmModal = result;
            })
            vm.$scope.actions = 'update';
        } else {
            vm.$scope.frmModal = {};
            vm.$scope.actions = 'create';
        }
        vm.openForm();
    }

    openForm() {
        vm.frm = new (vm.$dialog.prototype.extend({
            mdOptions: {
                title: (vm.$scope.actions === 'create') ? 'BUILDING.POPUP_MODAL.TITLE_CREATE' : 'BUILDING.POPUP_MODAL.TITLE_UPDATE',
                type: 'modal-md',
                alertType: 'success',
                content: require('./popup.html')
            }
        }))({
            $scope: vm.$scope
        });
        console.log(vm.frm);
        vm.frm.open();
    }

    confirmForm(buildingId) {
        if (!buildingId) {
            if (vm.$scope.selectionId.length <= 0) {
                vm.Noti5.warning({
                    message: `<u>${vm.$filter('translate')('SYSTEM.TITLE.WARNING')}</u>: ${vm.$filter('translate')('SYSTEM.NOTIFICATION.REQUIRED_CHOOSE_ITEM')}`,
                    delay: 5000,
                    positionY: 'bottom',
                    positionX: 'left'
                });
                return;
            }
        }
        vm.$scope.buildingIdCached = buildingId;
        vm.frmConfirm = new (vm.$dialog.prototype.extend({
            mdOptions: {
                title: (vm.$scope.actions === 'create') ? 'BUILDING.POPUP_MODAL.TITLE_CREATE' : 'BUILDING.POPUP_MODAL.TITLE_UPDATE',
                type: 'modal-md',
                alertType: 'success',
                content: `{{'SYSTEM.NOTIFICATION.CONFIRM_DELETE' | translate}}`,
                button: [
                    { name: 'SYSTEM.BUTTON.OK', type: 'info', click: (buildingId) ? vm.deleteBuilding : vm.deleteBuildingMutil },
                    { name: 'SYSTEM.BUTTON.CANCEL', type: 'info' },
                ]
            }
        }))({
            $scope: vm.$rootScope.$new()
        });
        vm.frmConfirm.open();
    }
}