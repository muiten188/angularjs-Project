import BuildingController from './building.controller';

var routing = [
    '$stateProvider', '$config',
    function ($stateProvider, $config) {
        var $p = $config.PAGECF('BUILDING');
        $stateProvider
            .state($p.state, {
                url: $p.url,
                template: require('./building.html'),
                controller: 'BuildingController',
                controllerAs: 'vm',
                data: {
                    name: $p.name
                }
            })
    }
];

export default angular.module('app.building', [])
    .controller('BuildingController', BuildingController)
    .config(routing)
    .name;