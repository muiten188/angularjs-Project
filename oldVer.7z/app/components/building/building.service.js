export class BuildingService {

    constructor($api) {
        this.$inject = ['$api']; this.$api = $api;
    }

    createBuilding(params) {
        return this.$api.post(
            'building/', params
        );
    }

    updateBuilding(params) {
        return this.$api.put(
            'building/', params
        );
    }

    deleteBuilding(params) {
        return this.$api.delete(
            'building/' + params.$id, {}
        );
    }

    deleteBuildingMutil(params) {
        return this.$api.delete(
            'building/multil/', params
        );
    }

    getBuildingbyId(params) {
        return this.$api.get(
            'building/' + params.$id + '/id', {}
        );
    }

    searchBuilding(params) {
        return this.$api.get(
            'building/', params, 'table'
        );
    }

    getAll() {
        return this.$api.get(
            'building/all', {}, 'table'
        );
    }
}