export class ChangePWDService {

    constructor($api) {
        this.$inject = ['$api']; this.$api = $api;
    }

    changePwd(params) {
        return this.$api.put(
            '/users/updatePassword/', params
        );
    }
}