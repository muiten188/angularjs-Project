import { ChangePWDService } from './change-pwd.service';

let self;
let config;

export default class ChangePWDController {

    constructor($config, $rootScope, $scope, $modal, $api, Notification, $helper, $state) {

        this.$inject = ['$config', '$rootScope', '$scope', '$modal', '$api', 'Notification', '$helper', '$state'];

        self = this;
        config = $config;

        $scope.fnMenu = $config.MENU;
        $scope.stateName = $state.current.name;
        $scope.codePage = 'page:' + $config.PAGE($state.current.name);

        this.$rootScope = $rootScope;
        this.$scope = $scope;
        this.$modal = $modal;
        this.$noti5 = Notification;
        this.$helper = $helper;

        this.setDefault();

        // connect service
        this.$changePWDApi = new ChangePWDService($api);

        this.$scope.changePwd = this.changePwd;
        // fix height project
        $helper.heightUi();
    }

    setDefault() {
        self.$scope.frmChangePwd = {
            passwordOld: '',
            passwordNew: '',
            passwordReNew: ''
        }
    }

    changePwd() {
        if (self.$scope.frmChangePwd.passwordReNew === self.$scope.frmChangePwd.passwordNew) {
            self.$changePWDApi.changePwd({
                "confirmPassword": self.$scope.frmChangePwd.passwordReNew,
                "newPassword": self.$scope.frmChangePwd.passwordNew,
                "oldPassword": self.$scope.frmChangePwd.passwordOld
            }).then(
                (result) => {
                    self.$noti5.success({ message: '<u>Thông báo:</u> Đổi mật khẩu thành công.', delay: 5000, positionY: 'bottom', positionX: 'right' });
                    self.setDefault();
                },
                (error) => {
                    if (angular.isDefined(error) && angular.isDefined(error.data[0].message)) {
                        self.$noti5.error({ message: '<u>Thông báo:</u> ' + error.data[0].message, delay: 5000, positionY: 'bottom', positionX: 'right' });
                    }else if (angular.isDefined(error) && angular.isDefined(error.data.message)){
                        self.$noti5.error({ message: '<u>Thông báo:</u> ' + error.data.message, delay: 5000, positionY: 'bottom', positionX: 'right' });
                    }
                    self.setDefault();
                }
            );
        }else{
            self.$noti5.error({ message: '<u>Thông báo:</u> Mật khẩu mới và mật khẩu nhập lại không giống nhau.', delay: 5000, positionY: 'bottom', positionX: 'right' });
            return;
        }
    }

}