export class UserService {

    constructor($api) {
        this.$inject = ['$api']; this.$api = $api;
    }

    createUser(params) {
        return this.$api.post(
            'user/', params
        );
    }

    updateUser(params) {
        return this.$api.put(
            'user/', params
        );
    }

    deleteUser(params) {
        return this.$api.delete(
            'user/' + params.$id, {}
        );
    }

    deleteUserMutil(params) {
        return this.$api.delete(
            'user/multil/', params
        );
    }

    getUserbyId(params) {
        return this.$api.get(
            'user/' + params.$id + '/id', {}
        );
    }

    searchUser(params) {
        return this.$api.get(
            'user/', params, 'table'
        );
    }
}