import UserController from './user.controller';
import ChangePWDController from './change-pwd/change-pwd.controller';

var routing = [
    '$stateProvider', '$config',
    function ($stateProvider, $config) {
        var $puser = $config.PAGECF('USER');
        var $pchanepwd = $config.PAGECF('CHANGEPWD');
        $stateProvider
            .state($puser.state, {
                url: $puser.url,
                template: require('./user.html'),
                controller: 'UserController',
                controllerAs: 'vm',
                data: {
                    name: $puser.name
                }
            })
            .state($pchanepwd.state, {
                url: $pchanepwd.url,
                template: require('./change-pwd/change-pwd.html'),
                controller: 'ChangePWDController',
                controllerAs: 'vm',
                data: {
                    name: $pchanepwd.name
                }
            });
    }
];

export default angular.module('app.user', [])
    .controller('UserController', UserController)
    .controller('ChangePWDController', ChangePWDController)
    .config(routing)
    .name;