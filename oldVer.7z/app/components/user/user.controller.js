import { UserService } from './user.service';
import { RoleService } from '../role/role.service';

let vm;
let config;

export default class UserController {

    constructor($config, $rootScope, $scope, $filter, $api, $helper, $state, $translate, $dialog, Notification) {
        this.$inject = ['$config', '$rootScope', '$scope', '$filter', '$api', '$helper', '$state', '$translate', '$dialog', 'Notification'];
        vm = this;
        config = $config;

        // permission
        $scope.menu = $config.MENU;
        $scope.stateName = $state.current.name;
        $scope.codePage = 'page:' + $config.PAGE($state.current.name);

        vm.$rootScope = $rootScope;
        vm.$scope = $scope;
        vm.$filter = $filter;
        vm.Noti5 = Notification;
        vm.$helper = $helper;
        vm.$dialog = $dialog;

        // connect service
        vm.UserService = new UserService($api);
        vm.RoleService = new RoleService($api);
        vm.searchEmployeeUrl = $config.BASE_URL_API + 'employee/name';

        // create the list
        vm.$scope.listStatus = [
            { key: 'ACTIVE', value: 'USER.SEARCH_SCREEN.STATUS_VALUE_ACTIVE' },
            { key: 'INACTIVE', value: 'USER.SEARCH_SCREEN.STATUS_VALUE_INACTIVE' },
        ];
        vm.$scope.gridOptions = {
            header: [
                { headerHtml: vm.renderCheckbox, field: 'userId', css: "width: 5%; text-align:center;", func: vm.renderCheckList },
                { headerName: 'USER.TABLE_HEADER.EMPLOYEE_CODE', field: 'employeeCode', func: vm.renderEmployee },
                { headerName: 'USER.TABLE_HEADER.DOMAIN_ACCOUNT', field: 'domainAccount' },
                { headerName: 'USER.TABLE_HEADER.STATUS', field: 'status' },
                { headerName: 'USER.TABLE_HEADER.ROLE_GROUP_NAME', field: 'roleGroupName' },
                { headerName: 'USER.TABLE_HEADER.DESCRIPTION', field: 'description' },
                { headerName: 'USER.TABLE_HEADER.CREATED_DATE', field: 'createdDate', func: vm.renderDate },
            ],
            data: []
        }
        vm.$scope.pageOptions = angular.copy(config.PAGE_OPTIONS);

        // call function
        vm.getListRoles();
        vm.setDefault();
        vm.searchUser();
    }

    // render
    renderCheckbox() {
        return `<input type="checkbox" ng-model="controller.$scope.checkAll" ng-click="controller.toggleCheckAll()"/>`;
    }
    renderCheckList(rowItem) {
        return `<input ng-model="controller.$scope.listId[${rowItem.data.userId}]" ng-click="controller.toggleCheckItem(${rowItem.data.userId})" type="checkbox" />`
    }
    renderEmployee(rowItem) {
        return `<span class="href-link" ng-click="controller.chooseActions(${rowItem.data.userId})" ng-bind-html="'${rowItem.data.employeeCode}' | highlight:controller.$scope.frmSearch.employeeCode"></span>`
    }
    renderDate(rowItem) {
        return vm.$filter('date')(rowItem.data.createdDate, config.DATE_FORMAT);
    }
    renderAction(rowItem) {
        return `
        <div class="tools">
            <button ng-click="controller.chooseActions(${rowItem.data.userId})" data-toggle="tooltip" data-placement="top" title="{{'USER.SEARCH_SCREEN.BUTTON_EDIT' | translate}} ${rowItem.data.domainAccount}" class="btn btn-xs btn-warning"><i class="fa fa-edit"></i></button>
            <button ng-click="controller.deleteUser(${rowItem.data.userId})" data-toggle="tooltip" data-placement="top" title="{{'USER.SEARCH_SCREEN.BUTTON_DEL' | translate}} ${rowItem.data.domainAccount}" class="btn btn-xs btn-danger"><i class="fa fa-trash-o"></i></button>
        </div>
        `;
    }

    setDefault() {
        vm.$scope.checkAll = false;
        vm.$scope.listId = [];
        vm.$scope.selectionId = [];
        vm.$scope.frmSearch = {
            "employeeCode": "",
            "domainAccount": "",
            "status": "ACTIVE"
        }
    }

    toggleCheckAll() {
        vm.$scope.selectionId = [];
        vm.$scope.gridOptions.data.forEach((item) => {
            vm.$scope.listId[item.userId] = (vm.$scope.checkAll) ? true : false;
            if (vm.$scope.checkAll) vm.$scope.selectionId.push(item.userId);
        })
    }

    toggleCheckItem(userId) {
        if (userId) {
            var index = vm.$scope.selectionId.indexOf(userId);
            if (index < 0) {
                vm.$scope.selectionId.push(userId);
            } else {
                vm.$scope.selectionId.splice(index, 1);
            }
            vm.$scope.checkAll = (vm.$scope.selectionId.length >= vm.$scope.gridOptions.data.length) ? true : false;
        }
    }
    chooseActions(userId) {
        if (userId && angular.isNumber(userId)) {
            vm.UserService.getUserbyId({
                $id: userId
            }).then((result) => {
                vm.$scope.frmModal = result;
                vm.$scope.frmModal.roleGroupId = vm.$scope.frmModal.roleGroupId.toString();
            })
            vm.$scope.actions = 'update';
        } else {
            vm.$scope.frmModal = {
                "employeeCode": "",
                "roleGroupId": "1",
                "domainAccount": "",
                "description": "",
                "status": "ACTIVE"
            }
            vm.$scope.actions = 'create';
        }
        vm.openForm();
    }

    openForm() {
        vm.frm = new (vm.$dialog.prototype.extend({
            mdOptions: {
                title: (vm.$scope.actions === 'create') ? 'USER.POPUP_MODAL.TITLE_CREATE' : 'USER.POPUP_MODAL.TITLE_UPDATE',
                type: 'modal-md',
                alertType: 'success',
                content: require('./popup.html')
            }
        }))({
            $scope: vm.$scope
        });
        vm.frm.open();
    }

    confirmForm(userId) {
        if (!userId) {
            if (vm.$scope.selectionId.length <= 0) {
                vm.Noti5.warning({
                    message: `<u>${vm.$filter('translate')('SYSTEM.TITLE.WARNING')}</u>: ${vm.$filter('translate')('SYSTEM.NOTIFICATION.REQUIRED_CHOOSE_ITEM')}`,
                    delay: 5000,
                    positionY: 'bottom',
                    positionX: 'left'
                });
                return;
            }
        }
        vm.$scope.userIdCached = userId;
        vm.frmConfirm = new (vm.$dialog.prototype.extend({
            mdOptions: {
                title: (vm.$scope.actions === 'create') ? 'USER.POPUP_MODAL.TITLE_CREATE' : 'USER.POPUP_MODAL.TITLE_UPDATE',
                type: 'modal-md',
                alertType: 'success',
                content: `{{'SYSTEM.NOTIFICATION.CONFIRM_DELETE' | translate}}`,
                button: [
                    { name: 'SYSTEM.BUTTON.OK', type: 'info', click: (userId) ? vm.deleteUser : vm.deleteUserMutil },
                    { name: 'SYSTEM.BUTTON.CANCEL', type: 'info' },
                ]
            }
        }))({
            $scope: vm.$rootScope.$new()
        });
        vm.frmConfirm.open();
    }

    getListRoles() {
        vm.RoleService.searchAllRoles().then(
            (result) => {
                vm.$scope.listRoles = (result);
            }
        );
    }

    chooseEmployee(selected) {
        console.log(selected);
        if (selected && selected.originalObject)
            vm.$scope.frmModal.employeeCode = selected.originalObject.employeeCode;
    }

    remoteUrlRequestFn(str) {
        return { employeeName: str };
    }

    searchUser() {
        vm.UserService.searchUser({
            "employeeCode": vm.$scope.frmSearch.employeeCode,
            "domainAccount": vm.$scope.frmSearch.domainAccount,
            "status": vm.$scope.frmSearch.status,
            "pageSize": vm.$scope.pageOptions.pageSize,
            "currentPage": vm.$scope.pageOptions.currentPage
        }).then(
            (result) => {
                vm.$scope.gridOptions.data = (result.data);
                vm.$scope.pageOptions = {
                    totalPage: result.totalPage,
                    pageSize: result.pageSize,
                    currentPage: result.currentPage
                };
            }
        );
    }

    createUser() {
        console.log(vm.$scope.frmModal.employeeCode);
        vm.UserService.createUser({
            "employeeCode": vm.$scope.frmModal.employeeCode,
            "domainAccount": vm.$scope.frmModal.domainAccount,
            "roleGroupId": vm.$scope.frmModal.roleGroupId,
            "status": vm.$scope.frmModal.status,
            "description": vm.$scope.frmModal.description
        }).then(
            (result) => {
                vm.searchUser();
                vm.frm.close();
                vm.Noti5.success({
                    message: `<u>${vm.$filter('translate')('SYSTEM.TITLE.INFO')}</u>: ${vm.$filter('translate')('SYSTEM.NOTIFICATION.SUCCESS_ADD')}`,
                    delay: 5000,
                    positionY: 'bottom',
                    positionX: 'left'
                });
            }
        );
    }

    updateUser() {
        vm.UserService.updateUser({
            "userId": vm.$scope.frmModal.userId,
            "employeeCode": vm.$scope.frmModal.employeeCode,
            "domainAccount": vm.$scope.frmModal.domainAccount,
            "roleGroupId": vm.$scope.frmModal.roleGroupId,
            "status": vm.$scope.frmModal.status,
            "description": vm.$scope.frmModal.description
        }).then(
            (result) => {
                vm.searchUser();
                vm.frm.close();
                vm.Noti5.success({
                    message: `<u>${vm.$filter('translate')('SYSTEM.TITLE.INFO')}</u>: ${vm.$filter('translate')('SYSTEM.NOTIFICATION.SUCCESS_UPDATE')}`,
                    delay: 5000,
                    positionY: 'bottom',
                    positionX: 'left'
                });
            }
        );
    }

    deleteUser(userId) {
        vm.UserService.deleteUser({
            $id: vm.$scope.userIdCached
        }).then(
            (result) => {
                vm.searchUser();
                vm.frmConfirm.close();
                vm.frm.close();
                vm.Noti5.success({
                    message: `<u>${vm.$filter('translate')('SYSTEM.TITLE.INFO')}</u>: ${vm.$filter('translate')('SYSTEM.NOTIFICATION.SUCCESS_DELETE')}`,
                    delay: 5000,
                    positionY: 'bottom',
                    positionX: 'left'
                });
            });
    }

    deleteUserMutil() {
        vm.UserService.deleteUserMutil({
            listId: vm.$scope.selectionId
        }).then(
            (result) => {
                vm.searchUser();
                vm.frmConfirm.close();
                vm.frm.close();
                vm.Noti5.success({
                    message: `<u>${vm.$filter('translate')('SYSTEM.TITLE.INFO')}</u>: ${vm.$filter('translate')('SYSTEM.NOTIFICATION.SUCCESS_DELETE')}`,
                    delay: 5000,
                    positionY: 'bottom',
                    positionX: 'left'
                });
            }
        );
    }

}