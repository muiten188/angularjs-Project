"use strict";
/* global angular */

import UserModule from './user';
import RoleModule from './role';
import DepartmentModule from './department';
import BuildingModule from './building';
import FloorModule from './floor';
import ApartmentModule from './apartment';
import GroupModule from './group';

export default angular.module('app.components', [
    UserModule,
    RoleModule,
    DepartmentModule,
    BuildingModule,
    FloorModule,
    ApartmentModule,
    GroupModule
]).name;