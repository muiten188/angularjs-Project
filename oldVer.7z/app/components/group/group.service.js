export class GroupService {

    constructor($api) {
        this.$inject = ['$api'];
        this.$api = $api;
    }

    createGroup(params) {
        params = params || {};
        params['fake'] = true;
        return this.$api.get(
            '/data/crud.json', params
        );
    }

    updateGroup(params) {
        params = params || {};
        params['fake'] = true;
        return this.$api.get(
            '/data/crud.json', params
        );
    }

    deleteGroup(params) {
        params = params || {};
        params['fake'] = true;
        return this.$api.get(
            '/data/crud.json' + params.$id, {}
        );
    }

    deleteGroupMutil(params) {
        params = params || {};
        params['fake'] = true;
        return this.$api.get(
            '/data/crud.json', params
        );
    }

    getGroupbyId(params) {
        params = params || {};
        params['fake'] = true;
        return this.$api.get(
            '/data/group.json', params
        ).then((result) => {
            return result.data.find(item => item.groupId === params.$id);
        })
    }

    searchGroup(params) {
        params = params || {};
        params['fake'] = true;
        return this.$api.get(
            '/data/group.json', { 'fake': true }
        );
    }
}