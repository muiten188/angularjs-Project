import GroupController from './group.controller';

var routing = [
    '$stateProvider', '$config',
    function ($stateProvider, $config) {
        var $p = $config.PAGECF('GROUP');
        $stateProvider
            .state($p.state, {
                url: $p.url,
                template: require('./group.html'),
                controller: 'GroupController',
                controllerAs: 'vm',
                data: {
                    name: $p.name
                }
            })
    }
];

export default angular.module('app.group', [])
    .controller('GroupController', GroupController)
    .config(routing)
    .name;