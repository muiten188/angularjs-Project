export class DepartmentService {

    constructor($api) {
        this.$inject = ['$api']; this.$api = $api;
    }

    createDepartment(params) {
        return this.$api.post(
            'department/', params
        );
    }

    updateDepartment(params) {
        return this.$api.put(
            'department/', params
        );
    }

    deleteDepartment(params) {
        return this.$api.delete(
            'department/' + params.$id, {}
        );
    }

    deleteDepartmentMutil(params) {
        return this.$api.delete(
            'department/multil/', params
        );
    }

    getDepartmentbyId(params) {
        return this.$api.get(
            'department/' + params.$id + '/id', {}
        );
    }

    searchDepartment(params) {
        return this.$api.get(
            'department/', params, 'table'
        );
    }

    searchAllDepartment() {
        return this.$api.get(
            'department/load-all', {}, 'table'
        );
    }
}