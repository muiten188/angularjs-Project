import { DepartmentService } from './department.service';

let vm;
let config;

export default class DepartmentController {

    constructor($config, $rootScope, $scope, $filter, $api, $helper, $state, $translate, $dialog, Notification) {

        vm = this;
        config = $config;

        // permission
        $scope.menu = $config.MENU;
        $scope.stateName = $state.current.name;
        $scope.codePage = 'page:' + $config.PAGE($state.current.name);

        vm.$rootScope = $rootScope;
        vm.$scope = $scope;
        vm.$filter = $filter;
        vm.Noti5 = Notification;
        vm.$helper = $helper;
        vm.$dialog = $dialog;

        // connect service
        vm.DepartmentService = new DepartmentService($api);

        // create the list
        vm.$scope.listDepartmentParents = [];
        vm.$scope.gridOptions = {
            header: [
                { headerHtml: vm.renderCheckbox, field: 'departmentId', css: "width: 5%; text-align:center;", func: vm.renderCheckList },
                { headerName: 'DEPARTMENT.TABLE_HEADER.DEPARTMENT_NAME', field: 'departmentName', func: vm.renderDepartment },
                { headerName: 'DEPARTMENT.TABLE_HEADER.DEPARTMENT_PARENTS', field: 'parentName', func: vm.renderParent },
                { headerName: 'DEPARTMENT.TABLE_HEADER.DESCRIPTION', field: 'description' },
                { headerName: 'DEPARTMENT.TABLE_HEADER.CREATED_DATE', field: 'createdDate', func: vm.renderDate },
            ],
            data: []
        }
        vm.$scope.pageOptions = angular.copy(config.PAGE_OPTIONS);

        // call function
        vm.setDefault();
        vm.searchDepartment();
    }

    // render
    renderCheckbox() {
        return `<input type="checkbox" ng-model="controller.$scope.checkAll" ng-click="controller.toggleCheckAll()"/>`;
    }
    renderCheckList(rowItem) {
        return `<input ng-model="controller.$scope.listId[${rowItem.data.departmentId}]" ng-click="controller.toggleCheckItem(${rowItem.data.departmentId})" type="checkbox" />`
    }
    renderDepartment(rowItem) {
        return `<span class="href-link" ng-click="controller.chooseActions(${rowItem.data.departmentId})" ng-bind-html="'${rowItem.data.departmentName}' | highlight:controller.$scope.frmSearch.departmentName"></span>`
    }
    renderParent(rowItem) {
        return rowItem.data.parentName == "" ? "" : rowItem.data.parentName;
    }
    renderDate(rowItem) {
        return vm.$filter('date')(rowItem.data.createdDate, config.DATE_FORMAT);
    }
    renderAction(rowItem) {
        return `
        <div class="tools">
            <button ng-click="controller.chooseActions(${rowItem.data.departmentId})" data-toggle="tooltip" data-placement="top" title="{{'DEPARTMENT.SEARCH_SCREEN.BUTTON_EDIT' | translate}} ${rowItem.data.userName}" class="btn btn-xs btn-warning"><i class="fa fa-edit"></i></button>
            <button ng-click="controller.deleteDepartment(${rowItem.data.departmentId})" data-toggle="tooltip" data-placement="top" title="{{'DEPARTMENT.SEARCH_SCREEN.BUTTON_DEL' | translate}} ${rowItem.data.userName}" class="btn btn-xs btn-danger"><i class="fa fa-trash-o"></i></button>
        </div>
        `;
    }

    setDefault() {
        vm.$scope.checkAll = false;
        vm.$scope.listId = [];
        vm.$scope.selectionId = [];
        vm.$scope.frmSearch = {
            "departmentCode": "",
            "userName": "",
            "status": "ACTIVE"
        }
    }

    toggleCheckAll() {
        vm.$scope.selectionId = [];
        vm.$scope.gridOptions.data.forEach((item) => {
            vm.$scope.listId[item.departmentId] = (vm.$scope.checkAll) ? true : false;
            if (vm.$scope.checkAll) vm.$scope.selectionId.push(item.departmentId);
        })
    }

    toggleCheckItem(departmentId) {
        if (departmentId) {
            var index = vm.$scope.selectionId.indexOf(departmentId);
            if (index < 0) {
                vm.$scope.selectionId.push(departmentId);
            } else {
                vm.$scope.selectionId.splice(index, 1);
            }
            vm.$scope.checkAll = (vm.$scope.selectionId.length >= vm.$scope.gridOptions.data.length) ? true : false;
        }
    }

    chooseActions(departmentId) {
        if (departmentId && angular.isNumber(departmentId)) {
            vm.DepartmentService.getDepartmentbyId({
                $id: departmentId
            }).then((result) => {
                vm.$scope.frmModal = result;
                if (vm.$scope.frmModal.parentId) {
                    vm.parentName = vm.$scope.gridOptions.data.filter((item) => {
                        return item.departmentId === vm.$scope.frmModal.parentId;
                    })[0].departmentName;
                }
            })
            vm.$scope.actions = 'update';
        } else {
            vm.$scope.frmModal = {
                "departmentName": "",
                "parentId": null,
                "description": ""
            }
            vm.$scope.actions = 'create';
        }
        vm.openForm();
    }

    openForm() {
        vm.frm = new (vm.$dialog.prototype.extend({
            mdOptions: {
                title: (vm.$scope.actions === 'create') ? 'DEPARTMENT.POPUP_MODAL.TITLE_CREATE' : 'DEPARTMENT.POPUP_MODAL.TITLE_UPDATE',
                type: 'modal-md',
                alertType: 'success',
                content: require('./popup.html')
            }
        }))({
            $scope: vm.$scope
        });
        vm.frm.open();
    }

    confirmForm(departmentId) {
        if (!departmentId) {
            if (vm.$scope.selectionId.length <= 0) {
                vm.Noti5.warning({
                    message: `<u>${vm.$filter('translate')('SYSTEM.TITLE.WARNING')}</u>: ${vm.$filter('translate')('SYSTEM.NOTIFICATION.REQUIRED_CHOOSE_ITEM')}`,
                    delay: 5000,
                    positionY: 'bottom',
                    positionX: 'left'
                });
                return;
            }
        }
        vm.$scope.departmentIdCached = departmentId;
        vm.frmConfirm = new (vm.$dialog.prototype.extend({
            mdOptions: {
                title: (vm.$scope.actions === 'create') ? 'DEPARTMENT.POPUP_MODAL.TITLE_CREATE' : 'DEPARTMENT.POPUP_MODAL.TITLE_UPDATE',
                type: 'modal-md',
                alertType: 'success',
                content: `{{'SYSTEM.NOTIFICATION.CONFIRM_DELETE' | translate}} {{selectionId | json}}`,
                button: [
                    { name: 'SYSTEM.BUTTON.OK', type: 'info', click: (departmentId) ? vm.deleteDepartment : vm.deleteDepartmentMutil },
                    { name: 'SYSTEM.BUTTON.CANCEL', type: 'info' },
                ]
            }
        }))({
            $scope: vm.$rootScope.$new()
        });
        vm.frmConfirm.open();
    }

    chooseDepartment(type) {
        vm.DepartmentService.searchAllDepartment().then(
            (result) => {
                var scopeModal = vm.$rootScope.$new();
                if (type != 'readonly') {
                    scopeModal.valueSelect = vm.$scope.frmModal.parentId;
                } else {
                    scopeModal.readOnly = true;
                }
                scopeModal.listDepartmentParents = (result);
                vm.modalDepartment = new (vm.$dialog.prototype.extend({
                    mdOptions: {
                        title: 'DEPARTMENT.POPUP_MODAL.TITLE_CHOOSE',
                        type: 'modal-md',
                        alertType: 'success',
                        content: `<department-tree list="listDepartmentParents" read-only="readOnly" value="valueSelect" is-open="true" field-show="departmentName" field-group="parentId" field-id="departmentId"></department-tree>`,
                        button: [

                        ]
                    }
                }))({
                    $scope: scopeModal
                });

                vm.modalDepartment.open();

                // watch info from popup department;
                if (type != 'readonly') {
                    vm.$rootScope.$on("IdTreeView", function (event, data) {
                        vm.parentName = data.departmentName;
                        vm.$scope.frmModal.parentId = data.departmentId;
                        vm.modalDepartment.close();
                    });
                }
            }
        );
    }

    searchDepartment() {
        vm.DepartmentService.searchDepartment({
            "departmentName": vm.$scope.frmSearch.departmentName,
            "description": vm.$scope.frmSearch.description,
            "pageSize": vm.$scope.pageOptions.pageSize,
            "currentPage": vm.$scope.pageOptions.currentPage
        }).then(
            (result) => {
                vm.$scope.gridOptions.data = (result.data);
                vm.$scope.pageOptions = {
                    totalPage: result.totalPage,
                    pageSize: result.pageSize,
                    currentPage: result.currentPage
                };
            },
        );
    }

    createDepartment() {
        vm.DepartmentService.createDepartment({
            "departmentName": vm.$scope.frmModal.departmentName,
            "description": vm.$scope.frmModal.description,
            "parentId": vm.$scope.frmModal.parentId
        }).then(
            (result) => {
                vm.searchDepartment();
                vm.frm.close();
                vm.Noti5.success({
                    message: `<u>${vm.$filter('translate')('SYSTEM.TITLE.INFO')}</u>: ${vm.$filter('translate')('SYSTEM.NOTIFICATION.SUCCESS_ADD')}`,
                    delay: 5000,
                    positionY: 'bottom',
                    positionX: 'left'
                });
            }, );
    }

    updateDepartment() {
        vm.DepartmentService.updateDepartment({
            "departmentId": vm.$scope.frmModal.departmentId,
            "departmentName": vm.$scope.frmModal.departmentName,
            "description": vm.$scope.frmModal.description,
            "parentId": vm.$scope.frmModal.parentId
        }).then(
            (result) => {
                vm.searchDepartment();
                vm.frm.close();
                vm.Noti5.success({
                    message: `<u>${vm.$filter('translate')('SYSTEM.TITLE.INFO')}</u>: ${vm.$filter('translate')('SYSTEM.NOTIFICATION.SUCCESS_UPDATE')}`,
                    delay: 5000,
                    positionY: 'bottom',
                    positionX: 'left'
                });
            },
        );
    }

    deleteDepartment(departmentId) {
        vm.DepartmentService.deleteDepartment({
            $id: vm.$scope.departmentIdCached
        }).then(
            (result) => {
                vm.searchDepartment();
                vm.frmConfirm.close();
                vm.frm.close();
                vm.Noti5.success({
                    message: `<u>${vm.$filter('translate')('SYSTEM.TITLE.INFO')}</u>: ${vm.$filter('translate')('SYSTEM.NOTIFICATION.SUCCESS_DELETE')}`,
                    delay: 5000,
                    positionY: 'bottom',
                    positionX: 'left'
                });
            },
        );
    }

    deleteDepartmentMutil() {
        vm.DepartmentService.deleteDepartmentMutil({
            listId: vm.$scope.selectionId
        }).then(
            (result) => {
                vm.searchDepartment();
                vm.frmConfirm.close();
                vm.frm.close();
                vm.Noti5.success({
                    message: `<u>${vm.$filter('translate')('SYSTEM.TITLE.INFO')}</u>: ${vm.$filter('translate')('SYSTEM.NOTIFICATION.SUCCESS_DELETE')}`,
                    delay: 5000,
                    positionY: 'bottom',
                    positionX: 'left'
                });
            },
        );
    }

}