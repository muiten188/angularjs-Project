import DepartmentController from './department.controller';

var routing = [
    '$stateProvider', '$config',
    function ($stateProvider, $config) {
        var $p = $config.PAGECF('DEPARTMENT');
        $stateProvider
            .state($p.state, {
                url: $p.url,
                template: require('./department.html'),
                controller: 'DepartmentController',
                controllerAs: 'vm',
                data: {
                    name: $p.name
                }
            })
    }
];

export default angular.module('app.department', [])
    .controller('DepartmentController', DepartmentController)
    .config(routing)
    .name;