export class ApartmentService {

    constructor($api) {
        this.$inject = ['$api']; 
        this.$api = $api;
    }

    createApartment(params) {
        return this.$api.post(
            'apartment/', params
        );
    }

    updateApartment(params) {
        return this.$api.put(
            'apartment/', params
        );
    }

    deleteApartment(params) {
        return this.$api.delete(
            'apartment/' + params.$id, {}
        );
    }

    deleteApartmentMutil(params) {
        return this.$api.delete(
            'apartment/multil/', params
        );
    }

    getApartmentbyId(params) {
        return this.$api.get(
            'apartment/' + params.$id + '/id', {}
        );
    }

    getApartmentDtoById(params) {
        return this.$api.get(
            'apartment/' + params.$id + '/dto', {}
        );
    }

    searchApartment(params) {
        return this.$api.get(
            'apartment/', params, 'table'
        );
    }

    findApartmentPlan(params) {
        return this.$api.get(
            'upload/apartment/' + params.$id, {}
        );
    }

}