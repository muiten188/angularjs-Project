import { ApartmentService } from './apartment.service';
import { FloorService } from '../floor/floor.service';
import { BuildingService } from '../building/building.service';
let vm;
let config;

export default class ApartmentController {

    constructor($config, $rootScope, $scope, $filter, $api, $helper, $state, $translate, $dialog, Notification, Upload) {

        this.$inject = ['$config', '$rootScope', '$scope', '$filter', '$api', '$helper', '$state', '$translate', '$dialog', 'Notification', 'Upload'];

        vm = this;
        config = $config;

        // permission
        $scope.menu = $config.MENU;
        $scope.stateName = $state.current.name;
        $scope.codePage = 'page:' + $config.PAGE($state.current.name); 

        vm.$rootScope = $rootScope;
        vm.$scope = $scope;
        vm.$filter = $filter;
        vm.Noti5 = Notification;
        vm.$helper = $helper;
        vm.$dialog = $dialog;

        // connect service
        vm.$apartmentApi = new ApartmentService($api);
        vm.$buildingApi = new BuildingService($api);
        vm.$floorApi = new FloorService($api);

        vm.$scope.gridOptions = {
            header: [
                { headerHtml: vm.renderCheckbox, field: 'apartmentId', css: "width: 5%; text-align:center;", func: vm.renderCheckList },
                { headerName: 'APARTMENT.TABLE_HEADER.APARTMENT_NAME', field: '', func: vm.renderApartment },
                { headerName: 'FLOOR.TABLE_HEADER.FLOOR_CODE', field: 'floorCode' },
                { headerName: 'BUILDING.TABLE_HEADER.BUILDING_CODE', field: 'buildingCode' },
                { headerName: 'APARTMENT.TABLE_HEADER.PLAN', field: 'plan' },
                { headerName: 'APARTMENT.TABLE_HEADER.AREA', field: 'area' },
                { headerName: 'APARTMENT.TABLE_HEADER.NUMBER_BEDROOM', field: 'numberBedroom' }
            ],
            data: []
        }
        vm.$scope.pageOptions = angular.copy(config.PAGE_OPTIONS);

        vm.$scope.uploadFiles = function (files) {
            if (files && files.length) {
                for (var i = 0; i < files.length; i++) {
                    var file = files[i];
                    if (!file.$error) {
                        Upload.upload({
                            url: $api.URL('upload/'),
                            data: {
                                file: file
                            }
                        }).then(function (resp) {
                            if (!vm.$scope.frmModal.plans) {
                                vm.$scope.frmModal.plans = [];
                            }
                            vm.$scope.frmModal.plans.push(resp.data);
                        }, null, function (evt) {
                            console.log(evt);
                        });
                    }
                }
            }
        };

        vm.setDefault();
        vm.loadPreData();
        vm.searchApartment();
    }

    // render
    renderCheckbox() {
        return `<input type="checkbox" ng-model="controller.$scope.checkAll" ng-click="controller.toggleCheckAll()"/>`;
    }
    renderCheckList(rowItem) {
        return `<input ng-model="controller.$scope.listId[${rowItem.data.apartmentId}]" ng-click="controller.toggleCheckItem(${rowItem.data.apartmentId})" type="checkbox" />`
    }
    renderApartment(rowItem) {
        return `<span class="href-link" ng-click="controller.chooseActions(${rowItem.data.apartmentId})" ng-bind-html="'${rowItem.data.name}' | highlight:controller.$scope.frmSearch.name"></span>`;
    }
    toggleCheckAll() {
        vm.$scope.selectionId = [];
        vm.$scope.gridOptions.data.forEach((item) => {
            vm.$scope.listId[item.apartmentId] = (vm.$scope.checkAll) ? true : false;
            if (vm.$scope.checkAll) vm.$scope.selectionId.push(item.apartmentId);
        })
    }
    toggleCheckItem(apartmentId) {
        if (apartmentId) {
            var index = vm.$scope.selectionId.indexOf(apartmentId);
            if (index < 0) {
                vm.$scope.selectionId.push(apartmentId);
            } else {
                vm.$scope.selectionId.splice(index, 1);
            }
            vm.$scope.checkAll = (vm.$scope.selectionId.length >= vm.$scope.gridOptions.data.length) ? true : false;
        }
    }

    setDefault() {
        vm.$scope.checkAll = false;
        vm.$scope.listId = [];
        vm.$scope.selectionId = [];
        vm.$scope.frmSearch = {
            "buildingCode": "",
        }
    }

    onBuildingChange() {
        vm.$floorApi
            .findByBuildingId({ $id: vm.$scope.frmModal.buildingId })
            .then(
            (result) => {
                vm.$scope.listFloor = result;
            });
    }

    loadPreData() {
        vm.$buildingApi
            .getAll()
            .then(
            (result) => {
                vm.$scope.listBuilding = result;
            });
    }

    searchApartment() {
        vm.$apartmentApi.searchApartment({
            "buildingCode": vm.$scope.frmSearch.buildingCode,
            "floorCode": vm.$scope.frmSearch.floorCode,
            "name": vm.$scope.frmSearch.name,
            "pageSize": vm.$scope.pageOptions.pageSize,
            "currentPage": vm.$scope.pageOptions.currentPage
        }).then(
            (result) => {
                vm.$scope.gridOptions.data = (result.data);
                vm.$scope.pageOptions = {
                    totalPage: result.totalPage,
                    pageSize: result.pageSize,
                    currentPage: result.currentPage
                };
            }
            );
    }

    createApartment() {
        vm.$apartmentApi.createApartment(vm.$scope.frmModal).then(
            (result) => {
                vm.searchApartment();
                vm.frm.close();
                vm.Noti5.success({
                    message: `<u>${vm.$filter('translate')('SYSTEM.TITLE.INFO')}</u>: ${vm.$filter('translate')('SYSTEM.NOTIFICATION.SUCCESS_ADD')}`,
                    delay: 5000,
                    positionY: 'bottom',
                    positionX: 'left'
                });
            });
    }

    updateApartment() {
        vm.$apartmentApi.updateApartment(vm.$scope.frmModal).then(
            (result) => {
                vm.searchApartment();
                vm.frm.close();
                vm.Noti5.success({
                    message: `<u>${vm.$filter('translate')('SYSTEM.TITLE.INFO')}</u>: ${vm.$filter('translate')('SYSTEM.NOTIFICATION.SUCCESS_UPDATE')}`,
                    delay: 5000,
                    positionY: 'bottom',
                    positionX: 'left'
                });
            });
    }

    deleteApartment(apartmentId) {
        vm.$apartmentApi.deleteApartment({
            $id: vm.$scope.apartmentIdCached
        }).then(
            (result) => {
                vm.searchApartment();
                vm.frmConfirm.close();
                vm.frm.close();
                vm.Noti5.success({
                    message: `<u>${vm.$filter('translate')('SYSTEM.TITLE.INFO')}</u>: ${vm.$filter('translate')('SYSTEM.NOTIFICATION.SUCCESS_DELETE')}`,
                    delay: 5000,
                    positionY: 'bottom',
                    positionX: 'left'
                });
            });
    }

    deleteApartmentMutil() {
        vm.$apartmentApi.deleteApartmentMutil({
            ids: vm.$scope.selectionId
        }).then(
            (result) => {
                vm.searchApartment();
                vm.frmConfirm.close();
                vm.frm.close();
                vm.Noti5.success({
                    message: `<u>${vm.$filter('translate')('SYSTEM.TITLE.INFO')}</u>: ${vm.$filter('translate')('SYSTEM.NOTIFICATION.SUCCESS_DELETE')}`,
                    delay: 5000,
                    positionY: 'bottom',
                    positionX: 'left'
                });
            });
    }

    chooseActions(apartmentId) {
        if (apartmentId && angular.isNumber(apartmentId)) {
            vm.$apartmentApi.getApartmentDtoById({
                $id: apartmentId
            }).then((result) => {
                vm.$scope.frmModal = result; 

                vm.$apartmentApi.findApartmentPlan({
                    $id: apartmentId
                }).then((result)=> {
                    vm.$scope.frmModal.plans = result;
                });

                vm.$floorApi
                    .findByBuildingId({ $id: vm.$scope.frmModal.buildingId })
                    .then(
                    (result) => {
                        vm.$scope.listFloor = result;
                    });
            });
            
            vm.$scope.actions = 'update';
        } else {
            vm.$scope.frmModal = {};
            vm.$scope.actions = 'create';
        }
        vm.openForm();
    }

    openForm() {
        vm.frm = new (vm.$dialog.prototype.extend({
            mdOptions: {
                title: (vm.$scope.actions === 'create') ? 'BUILDING.POPUP_MODAL.TITLE_CREATE' : 'BUILDING.POPUP_MODAL.TITLE_UPDATE',
                type: 'modal-md',
                alertType: 'success',
                content: require('./popup.html')
            }
        }))({
            $scope: vm.$scope
        });
        vm.frm.open();
    }

    confirmForm(apartmentId) {
        if (!apartmentId) {
            if (vm.$scope.selectionId.length <= 0) {
                vm.Noti5.warning({
                    message: `<u>${vm.$filter('translate')('SYSTEM.TITLE.WARNING')}</u>: ${vm.$filter('translate')('SYSTEM.NOTIFICATION.REQUIRED_CHOOSE_ITEM')}`,
                    delay: 5000,
                    positionY: 'bottom',
                    positionX: 'left'
                });
                return;
            }
        }
        vm.$scope.apartmentIdCached = apartmentId;
        vm.frmConfirm = new (vm.$dialog.prototype.extend({
            mdOptions: {
                title: (vm.$scope.actions === 'create') ? 'BUILDING.POPUP_MODAL.TITLE_CREATE' : 'BUILDING.POPUP_MODAL.TITLE_UPDATE',
                type: 'modal-md',
                alertType: 'success',
                content: `{{'SYSTEM.NOTIFICATION.CONFIRM_DELETE' | translate}}`,
                button: [
                    { name: 'SYSTEM.BUTTON.OK', type: 'info', click: (apartmentId) ? vm.deleteApartment : vm.deleteApartmentMutil },
                    { name: 'SYSTEM.BUTTON.CANCEL', type: 'info' },
                ]
            }
        }))({
            $scope: vm.$rootScope.$new()
        });
        vm.frmConfirm.open();
    }
}