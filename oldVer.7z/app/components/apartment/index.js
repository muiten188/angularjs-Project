import ApartmentController from './apartment.controller';

var routing = [
    '$stateProvider', '$config',
    function ($stateProvider, $config) {
        var $p = $config.PAGECF('APARTMENT');
        $stateProvider
            .state($p.state, {
                url: $p.url,
                template: require('./apartment.html'),
                controller: 'ApartmentController',
                controllerAs: 'vm',
                data: {
                    name: $p.name
                }
            })
    }
];

export default angular.module('app.apartment', [])
    .controller('ApartmentController', ApartmentController)
    .config(routing)
    .name;