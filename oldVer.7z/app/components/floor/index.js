import FloorController from './floor.controller';

var routing = [
    '$stateProvider', '$config',
    function ($stateProvider, $config) {
        var $p = $config.PAGECF('FLOOR');
        $stateProvider
            .state($p.state, {
                url: $p.url,
                template: require('./floor.html'),
                controller: 'FloorController',
                controllerAs: 'vm',
                data: {
                    name: $p.name
                }
            })
    }
];

export default angular.module('app.floor', [])
    .controller('FloorController', FloorController)
    .config(routing)
    .name;