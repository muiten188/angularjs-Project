export class FloorService {

    constructor($api) {
        this.$inject = ['$api']; this.$api = $api;
    }

    createFloor(params) {
        return this.$api.post(
            'floor/', params
        );
    }

    updateFloor(params) {
        return this.$api.put(
            'floor/', params
        );
    }

    deleteFloor(params) {
        return this.$api.delete(
            'floor/' + params.$id, {}
        );
    }

    deleteFloorMutil(params) {
        return this.$api.delete(
            'floor/multil/', params
        );
    }

    getFloorbyId(params) {
        return this.$api.get(
            'floor/' + params.$id + '/id', {}
        );
    }

    findByBuildingId(params) {
        return this.$api.get(
            'floor/findByBuildingId/' + params.$id, {}
        );
    }

    searchFloor(params) {
        return this.$api.get(
            'floor/', params, 'table'
        );
    }
}