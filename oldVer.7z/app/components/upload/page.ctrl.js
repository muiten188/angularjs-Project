"use strict";

let self;

export default class PageController {

    constructor($config, $rootScope, $scope, $filter, $api, Notification, $helper, $state, $translate, $dialog) {
        this.$inject = ['$config', '$rootScope', '$scope', '$filter', '$api', '$helper', '$state', '$translate', '$dialog', 'Notification'];
        self = this;
        this.$scope = $scope;
        this.$dialog = $dialog;

        var dropbox = document.getElementById("dropbox")
        $scope.dropText = 'Drop files here...';

        dropbox.addEventListener("dragenter", this.dragEnterLeave, false)
        dropbox.addEventListener("dragleave", this.dragEnterLeave, false)
        dropbox.addEventListener("dragover", function (evt) {
            evt.stopPropagation()
            evt.preventDefault()
            var clazz = 'not-available'
            var ok = evt.dataTransfer && evt.dataTransfer.types && evt.dataTransfer.types.indexOf('Files') >= 0
            $scope.$apply(function () {
                $scope.dropText = ok ? 'Drop files here...' : 'Only files are allowed!'
                $scope.dropClass = ok ? 'over' : 'not-available'
            })
        }, false)
        dropbox.addEventListener("drop", function (evt) {
            console.log('drop evt:', JSON.parse(JSON.stringify(evt.dataTransfer)))
            evt.stopPropagation()
            evt.preventDefault()
            $scope.$apply(function () {
                $scope.dropText = 'Drop files here...'
                $scope.dropClass = ''
            })
            var files = evt.dataTransfer.files;
            if (files.length > 0) {
                $scope.$apply(function () {
                    $scope.files = []
                    for (var i = 0; i < files.length; i++) {
                        $scope.files.push(files[i])
                    }
                })
            }
        }, false)
        //============== DRAG & DROP =============
    }

    // init event handlers
    dragEnterLeave(evt) {
        evt.stopPropagation()
        evt.preventDefault()
        self.$scope.$apply(function () {
            self.$scope.dropText = 'Drop files here...'
            self.$scope.dropClass = ''
        })
    }

    setFiles(element) {
        self.$scope.$apply(function (scope) {
            console.log('files:', element.files);
            // Turn the FileList object into an Array
            scope.files = []
            for (var i = 0; i < element.files.length; i++) {
                scope.files.push(element.files[i])
            }
            scope.progressVisible = false
        });
    };

    uploadFile() {
        var fd = new FormData();
        fd.append("name", 'vietnam')
        for (var i in self.$scope.files) {
            fd.append("uploadedFile", self.$scope.files[i])
        }
        var xhr = new XMLHttpRequest()
        xhr.upload.addEventListener("progress", self.uploadProgress, false)
        xhr.addEventListener("load", self.uploadComplete, false)
        xhr.addEventListener("error", self.uploadFailed, false)
        xhr.addEventListener("abort", self.uploadCanceled, false)
        xhr.open("POST", "http://113.171.23.144:8080/hr-api/candidate/")
        self.$scope.progressVisible = true
        xhr.send(fd)
    }

    uploadProgress(evt) {
        self.$scope.$apply(function () {
            if (evt.lengthComputable) {
                self.$scope.progress = Math.round(evt.loaded * 100 / evt.total)
            } else {
                self.$scope.progress = 'unable to compute'
            }
        })
    }

    uploadComplete(evt) {
        /* This event is raised when the server send back a response */
        // alert(evt.target.responseText)
    }

    uploadFailed(evt) {
        alert("There was an error attempting to upload the file.")
    }

    uploadCanceled(evt) {
        self.$scope.$apply(function () {
            self.$scope.progressVisible = false
        })
        alert("The upload has been canceled by the user or the browser dropped the connection.")
    }

}