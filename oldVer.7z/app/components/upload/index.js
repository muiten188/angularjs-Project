"use strict";

import PageController2 from './page.ctrl';

var routing = [
    '$stateProvider', '$config',
    function ($stateProvider, $config) {
        var $page = $config.PAGECF('PAGE2');
        $stateProvider
            .state($page.state, {
                url: $page.url,
                template: require('./page.html'),
                controller: 'PageController2',
                controllerAs: 'vm',
                data: {
                    name: $page.name
                }
            })
    }
];

export default angular.module('app.page2', [])
    .controller('PageController2', PageController2)
    .config(routing)
    .name;