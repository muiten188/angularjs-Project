export class FunctionService {

    constructor($api) {
        this.$inject = ['$api'];
        this.$api = $api;
    }

    searchFunction(params) {
        return this.$api.get(
            'function/', params, 'table'
        );
    }

    searchAllFunction() {
        return this.$api.get(
            'functions/load-all', {}, 'table'
        );
    }
}