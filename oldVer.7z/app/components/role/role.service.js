export class RoleService {

    constructor($api) {
        this.$inject = ['$api']; 
        this.$api = $api;
    }

    createRole(params) {
        return this.$api.post(
            'roles/', params
        );
    }

    updateRole(params) {
        return this.$api.put(
            'roles/', params
        );
    }

    deleteRole(params) {
        return this.$api.delete(
            'roles/' + params.$id, {}
        );
    }

    deleteRoleMutil(params) {
        return this.$api.delete(
            'roles/multil/', params
        );
    }

    getRolebyId(params) {
        return this.$api.get(
            'roles/' + params.$id + '/id', {}
        );
    }

    searchRole(params) {
        return this.$api.get(
            'roles/', params, 'table'
        );
    }

    searchAllRoles() {
        return this.$api.get(
            'roles/load-all', {}, 'table'
        );
    }
}