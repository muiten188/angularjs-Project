import RoleController from './role.controller';

var routing = [
    '$stateProvider', '$config',
    function ($stateProvider, $config) {
        var $p = $config.PAGECF('ROLE');
        $stateProvider
            .state($p.state, {
                url: $p.url,
                template: require('./role.html'),
                controller: 'RoleController',
                controllerAs: 'vm',
                data: {
                    name: $p.name
                }
            })
    }
];

export default angular.module('app.role', [])
    .controller('RoleController', RoleController)
    .config(routing)
    .name;