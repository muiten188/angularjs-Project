import { RoleService } from './role.service';
import { FunctionService } from './functions.service';

let vm;
let config;

export default class RoleController {

    constructor($config, $rootScope, $scope, $filter, $api, $helper, $state, $translate, $dialog, Notification) {

        vm = this;
        config = $config;

        // permission
        $scope.menu = $config.MENU;
        $scope.stateName = $state.current.name;
        $scope.codePage = 'page:' + $config.PAGE($state.current.name);

        vm.$rootScope = $rootScope;
        vm.$scope = $scope;
        vm.$filter = $filter;
        vm.Noti5 = Notification;
        vm.$helper = $helper;
        vm.$dialog = $dialog;

        // connect service
        vm.RoleService = new RoleService($api);
        vm.FunctionService = new FunctionService($api);

        // create the list
        vm.$scope.listRoleParents = [];
        vm.$scope.gridOptions = {
            header: [
                { headerHtml: vm.renderCheckbox, field: 'roleGroupId', css: "width: 5%; text-align:center; vertical-align: middle;", func: vm.renderCheckList },
                { headerName: 'ROLE.TABLE_HEADER.ROLE_NAME', css: "width: 10%; text-align:center; vertical-align: middle;", field: 'roleGroupName', func: vm.renderRole },
                { headerName: 'ROLE.TABLE_HEADER.FUNCTIONS', field: 'parentId', func: vm.renderFunctions },
            ],
            data: []
        }
        vm.$scope.pageOptions = angular.copy(config.PAGE_OPTIONS);

        // call function
        vm.getFunction();
        vm.setDefault();
        vm.searchRole();
    }

    // render
    renderCheckbox() {
        return `<input type="checkbox" ng-model="controller.$scope.checkAll" ng-click="controller.toggleCheckAll()"/>`;
    }
    renderCheckList(rowItem) {
        return `<input ng-model="controller.$scope.listId[${rowItem.data.roleGroupId}]" ng-click="controller.toggleCheckItem(${rowItem.data.roleGroupId})" type="checkbox" />`
    }
    renderRole(rowItem) {
        return `<span class="href-link" ng-click="controller.chooseActions(${rowItem.data.roleGroupId})" ng-bind-html="'${rowItem.data.roleGroupName}' | highlight:controller.$scope.frmSearch.groupName"></span>`
    }
    renderFunctions(rowItem) {
        var html = '';
        if (rowItem.data.functions) {
            var groupData = _.groupBy(rowItem.data.functions, 'code');
            for (var i in groupData) {
                html += `
                    <div class="col-md-4">
                    <ul class="tree">
                        <li>${i}</li>
                        <ul>`;
                groupData[i].forEach((item) => {
                    html += `<li>
                                <span>${item.functionId}</span>
                                <span class="label {{'${item.method}' | bgrMethod}}">${item.method}</span>
                                <span>${item.nameVi}</span>
                            </li>`
                });
                html += `</ul></ul>
                    </div>
                `
            }
        }
        return html;
    }

    setDefault() {
        vm.$scope.checkAll = false;
        vm.$scope.listId = [];
        vm.$scope.selectionId = [];
        vm.$scope.frmSearch = {
            "groupId": "",
            "groupName": ""
        }
    }

    toggleCheckAll() {
        vm.$scope.selectionId = [];
        vm.$scope.gridOptions.data.forEach((item) => {
            vm.$scope.listId[item.roleGroupId] = (vm.$scope.checkAll) ? true : false;
            if (vm.$scope.checkAll) vm.$scope.selectionId.push(item.roleGroupId);
        })
    }

    toggleCheckItem(roleGroupId) {
        if (roleGroupId) {
            var index = vm.$scope.selectionId.indexOf(roleGroupId);
            if (index < 0) {
                vm.$scope.selectionId.push(roleGroupId);
            } else {
                vm.$scope.selectionId.splice(index, 1);
            }
            vm.$scope.checkAll = (vm.$scope.selectionId.length >= vm.$scope.gridOptions.data.length) ? true : false;
        }
    }

    getFunction() {
        vm.FunctionService.searchAllFunction().then(
            (result) => { vm.$scope.listFunction = result; }
        )
    }

    chooseActions(roleGroupId) {
        if (roleGroupId && angular.isNumber(roleGroupId)) {
            vm.RoleService.getRolebyId({
                $id: roleGroupId
            }).then((result) => {
                vm.$scope.frmModal = result;
                var funcTmp = [];
                result.functions.forEach((item) => {
                    if (item.functionId)
                        funcTmp.push(item.functionId);
                })
                vm.$scope.frmModal.functions = funcTmp;
            })
            vm.$scope.actions = 'update';
        } else {
            vm.$scope.frmModal = {
                "roleGroupId": "",
                "roleGroupName": "",
                "functions": []
            }
            vm.$scope.actions = 'create';
        }
        vm.openForm();
    }

    openForm() {
        vm.frm = new (vm.$dialog.prototype.extend({
            mdOptions: {
                title: (vm.$scope.actions === 'create') ? 'ROLE.POPUP_MODAL.TITLE_CREATE' : 'ROLE.POPUP_MODAL.TITLE_UPDATE',
                type: 'modal-md',
                alertType: 'success',
                content: require('./popup.html')
            }
        }))({
            $scope: vm.$scope
        });
        vm.frm.open();
    }

    confirmForm(roleGroupId) {
        if (!roleGroupId) {
            if (vm.$scope.selectionId.length <= 0) {
                vm.Noti5.warning({
                    message: `<u>${vm.$filter('translate')('SYSTEM.TITLE.WARNING')}</u>: ${vm.$filter('translate')('SYSTEM.NOTIFICATION.REQUIRED_CHOOSE_ITEM')}`,
                    delay: 5000,
                    positionY: 'bottom',
                    positionX: 'left'
                });
                return;
            }
        }
        vm.$scope.roleGroupIdCached = roleGroupId;
        vm.frmConfirm = new (vm.$dialog.prototype.extend({
            mdOptions: {
                title: (vm.$scope.actions === 'create') ? 'ROLE.POPUP_MODAL.TITLE_CREATE' : 'ROLE.POPUP_MODAL.TITLE_UPDATE',
                type: 'modal-md',
                alertType: 'success',
                content: `{{'SYSTEM.NOTIFICATION.CONFIRM_DELETE' | translate}} {{selectionId | json}}`,
                button: [
                    { name: 'SYSTEM.BUTTON.OK', type: 'info', click: (roleGroupId) ? vm.deleteRole : vm.deleteRoleMutil },
                    { name: 'SYSTEM.BUTTON.CANCEL', type: 'info' },
                ]
            }
        }))({
            $scope: vm.$rootScope.$new()
        });
        vm.frmConfirm.open();
    }

    chooseRole(type) {
        vm.RoleService.searchAllRole().then(
            (result) => {
                var scopeModal = vm.$rootScope.$new();
                if (type != 'readonly') {
                    scopeModal.valueSelect = vm.$scope.frmModal.parentId;
                } else {
                    scopeModal.readOnly = true;
                }
                scopeModal.listRoleParents = (result);
                vm.modalRole = new (vm.$dialog.prototype.extend({
                    mdOptions: {
                        title: 'ROLE.POPUP_MODAL.TITLE_CHOOSE',
                        type: 'modal-sm',
                        alertType: 'success',
                        content: `<role-tree list="listRoleParents" read-only="readOnly" value="valueSelect" is-open="true" field-show="roleGroupName" field-group="parentId" field-id="roleGroupId"></role-tree>`,
                        button: [

                        ]
                    }
                }))({
                    $scope: scopeModal
                });

                vm.modalRole.open();

                // watch info from popup role;
                if (type != 'readonly') {
                    vm.$rootScope.$on("IdTreeView", function (event, data) {
                        vm.parentName = data.roleGroupName;
                        vm.$scope.frmModal.parentId = data.roleGroupId;
                        vm.modalRole.close();
                    });
                }
            }
        );
    }

    searchRole() {
        vm.RoleService.searchRole({
            "groupId": vm.$scope.frmSearch.groupId,
            "groupName": vm.$scope.frmSearch.groupName,
            "pageSize": vm.$scope.pageOptions.pageSize,
            "currentPage": vm.$scope.pageOptions.currentPage
        }).then(
            (result) => {
                vm.$scope.gridOptions.data = (result.data);
                vm.$scope.pageOptions = {
                    totalPage: result.totalPage,
                    pageSize: result.pageSize,
                    currentPage: result.currentPage
                };
            }
            );
    }

    createRole() {
        vm.RoleService.createRole({
            "roleGroupName": vm.$scope.frmModal.roleGroupName,
            "functions": vm.$scope.frmModal.functions
        }).then(
            (result) => {
                vm.searchRole();
                vm.frm.close();
                vm.Noti5.success({
                    message: `<u>${vm.$filter('translate')('SYSTEM.TITLE.INFO')}</u>: ${vm.$filter('translate')('SYSTEM.NOTIFICATION.SUCCESS_ADD')}`,
                    delay: 5000,
                    positionY: 'bottom',
                    positionX: 'left'
                });
            });
    }

    updateRole() {
        vm.RoleService.updateRole({
            "roleGroupId": vm.$scope.frmModal.roleGroupId,
            "roleGroupName": vm.$scope.frmModal.roleGroupName,
            "functions": vm.$scope.frmModal.functions
        }).then(
            (result) => {
                vm.searchRole();
                vm.frm.close();
                vm.Noti5.success({
                    message: `<u>${vm.$filter('translate')('SYSTEM.TITLE.INFO')}</u>: ${vm.$filter('translate')('SYSTEM.NOTIFICATION.SUCCESS_UPDATE')}`,
                    delay: 5000,
                    positionY: 'bottom',
                    positionX: 'left'
                });
            }
            );
    }

    deleteRole(roleGroupId) {
        vm.RoleService.deleteRole({
            $id: vm.$scope.roleGroupIdCached
        }).then(
            (result) => {
                vm.searchRole();
                vm.frmConfirm.close();
                vm.frm.close();
                vm.Noti5.success({
                    message: `<u>${vm.$filter('translate')('SYSTEM.TITLE.INFO')}</u>: ${vm.$filter('translate')('SYSTEM.NOTIFICATION.SUCCESS_DELETE')}`,
                    delay: 5000,
                    positionY: 'bottom',
                    positionX: 'left'
                });
            }
            );
    }

    deleteRoleMutil() {
        vm.RoleService.deleteRoleMutil({
            listId: vm.$scope.selectionId
        }).then(
            (result) => {
                vm.searchRole();
                vm.frmConfirm.close();
                vm.frm.close();
                vm.Noti5.success({
                    message: `<u>${vm.$filter('translate')('SYSTEM.TITLE.INFO')}</u>: ${vm.$filter('translate')('SYSTEM.NOTIFICATION.SUCCESS_DELETE')}`,
                    delay: 5000,
                    positionY: 'bottom',
                    positionX: 'left'
                });
            }
            );
    }

}