module.exports = {
    "IP": "127.0.0.1",
    "PORT": "8088",
    "OUTPUT_PATH": './build',
    "PUCLIC_PATH": '/',
    "BASE_URL_API": 'http://localhost:8090/'
}
/*
module.exports = {
    "IP": "127.0.0.1",
    "PORT": "8080",
    "OUTPUT_PATH": './build',
    "PUCLIC_PATH": '/',
    "BASE_URL_API": 'http://localhost:8090/'
}
 */